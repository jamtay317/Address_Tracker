﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("XUser")]
    public class User:ModelBase
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string EmailAddress { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string UserRights { get; set; }

        public bool HasAccess { get; set; }
    }
}