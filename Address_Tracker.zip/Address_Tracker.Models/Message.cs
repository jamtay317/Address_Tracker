﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("NotificationMessage")]
    public class Message:ModelBase
    {
        public string Subject { get; set; }

        [Column("Message")]
        public string NotificationMessage { get; set; }

        public string SenderName { get; set; }

        public string EmailAddress { get; set; }

        public string PhoneNumber { get; set; }

        public bool IsRead { get; set; }

        public DateTime DateSent { get; set; }

        public DateTime? DateRead { get; set; }
    }
}