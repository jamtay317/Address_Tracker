﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("PointType")]
    public class PointType:ItemData
    {
    }
}