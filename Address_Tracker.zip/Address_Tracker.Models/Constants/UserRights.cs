﻿namespace Address_Tracker.Models.Constants
{
    public class UserRights
    {
        public static (string saveName, string displayName) Admin => ("ADMIN", "Admin");

        public static (string saveName, string displayName) Editor => ("EDITOR" , "Editor");

        public static (string saveName, string displayName) Reader => ("READER", "Reader");

        public static (string saveName, string displayName)[] AllRights = new[] {Admin, Editor, Reader};
    }
}