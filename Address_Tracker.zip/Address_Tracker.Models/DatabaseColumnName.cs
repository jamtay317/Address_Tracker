﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("DataBaseColumnName")]
    public class DatabaseColumnName:ModelBase
    {
        public string CurrentName { get; set; }

        public string ExportName { get; set; }

        public int ListOrder { get; set; }

        public string Description { get; set; }
    }
}
