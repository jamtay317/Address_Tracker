﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("PowerCompany")]
    public class PowerCompany:ItemData
    {
    }
}