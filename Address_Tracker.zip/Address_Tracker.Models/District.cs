﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Address_Tracker.Models
{
    [Table("District")]
    public class District : ItemData { }
}