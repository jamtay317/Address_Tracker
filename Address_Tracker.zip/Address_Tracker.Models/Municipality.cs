﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Address_Tracker.Models
{
    [Table("Municipality")]
    public class Municipality:ItemData
    {
        
    }
}