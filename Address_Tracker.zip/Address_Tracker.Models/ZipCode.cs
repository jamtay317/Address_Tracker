﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("ZipCode")]
    public class ZipCode:ItemData
    {
    }
}