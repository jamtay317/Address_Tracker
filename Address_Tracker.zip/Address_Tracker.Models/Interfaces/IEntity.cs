﻿namespace Address_Tracker.Models.Interfaces
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}