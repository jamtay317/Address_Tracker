﻿using System.Text.RegularExpressions;

namespace Address_Tracker.Models
{
    public struct PhoneNumber
    {
        private const string Pattern = @"(\d{3})(\d{3})(\d{4})";

        public PhoneNumber(string value):this()
        {
            this.SetValue(value);
        }

        public string Value { get; private set; }

        public string UnformattedValue { get; private set; }

        public void SetValue(string phoneNumber)
        {
            UnformattedValue = phoneNumber;
            if (phoneNumber != null)
            {
                Value = Regex.Replace(UnformattedValue, Pattern, @"($1) $2-$3");
            }
        }

        public override string ToString()
        {
            return Value;
        }
    }
}