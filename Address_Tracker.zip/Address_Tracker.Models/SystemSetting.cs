﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("SystemSettings")]
    public class SystemSetting:ModelBase
    {
        public string ReciverEmailAddress { get; set; }

        public string SenderEmailAddress { get; set; }

        public string SenderEmailPassword { get; set; }

        public string SmtpHost { get; set; }

        public int SmtpPort { get; set; }

        public int SessionTimeOutInDays { get; set; }
    }
}
