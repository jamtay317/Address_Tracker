﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("ActiveSession")]
    public class ActiveSession:ModelBase
    {
        public string Username { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime LastLogin { get; set; }

        public DateTime Expires { get; set; }

        public static ActiveSession Create(string username)
        {
            return new ActiveSession()
            {
                StartDate = DateTime.Today,
                LastLogin = DateTime.Today,
                Username = username
            };
        }
    }
}