﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Models.Dtos
{
    public class AddressSearchDto
    {
        public int? Id { get; set; }

        public string PointType { get; set; }

        public int Page { get; set; } = 0;

        public int PageSize { get; set; } = 50;

        public int Start { get; set; }

        public string StreetName { get; set; }

        public int? Esn { get; set; }

        public string Notes { get; set; }

        public string ParcelNumber { get; set; }

        public string ZoningCode { get; set; }

        public int? HouseNumber { get; set; }

        public string County { get; set; }

        public string Municipality { get; set; }

        public int? UniqueId { get; set; }

        public int? District { get; set; }

        public string SubDivision { get; set; }

        public string Community { get; set; }
    }
}
