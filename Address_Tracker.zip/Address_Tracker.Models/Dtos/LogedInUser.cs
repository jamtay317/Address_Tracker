﻿using System;

namespace Address_Tracker.Models.Dtos
{
    public class LogedInUser
    {
        public string Username { get; set; }

        public string Role { get; set; }

        public int DaysUntillTimeout { get; set; }

        public DateTime LastLogin { get; set; }

        public DateTime SessionExpires { get; set; }
    }
}
