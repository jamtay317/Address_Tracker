﻿namespace Address_Tracker.Models.Dtos
{
    public class AddressResultDto
    {
        public int Id { get; set; }

        public string AppartmentNumber { get; set; }

        public string HouseNumber { get; set; }

        public string StreetName { get; set; }

        public string EsnNumber { get; set; }

        public string Description { get; set; }

        public string TotalAddress { get; set; }

        public string PointType { get; set; }

        public string Community { get; set; }

        public string ZoningCode { get; set; }

        public string District { get; set; }

        public string Notes { get; set; }
    }
}