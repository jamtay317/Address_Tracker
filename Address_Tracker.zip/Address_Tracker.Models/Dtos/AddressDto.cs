﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Models.Dtos
{
    public class AddressDto
    {
        public int HouseNumber { get; set; }

        public string AddressStreetName { get; set; }

        public string AppartmentNumber { get; set; }

        public string NameOfBusiness { get; set; }
        
        public string County { get; set; }

        public int? EsnNumber { get; set; }

        public string SubDivision { get; set; }

        public string PropertyDescription { get; set; }

        public string FirstPartOfStreetName { get; set; }

        public int StreetNumber { get; set; }

        public string RoadType { get; set; }

        public string StreetName { get; set; }

        public decimal? Longitude { get; set; }

        public decimal? Latitude { get; set; }
        
        public string TotalAddress { get; set; }
        
        public string Notes { get; set; }
        
        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public decimal? OldLongitude { get; set; }

        public decimal? OldLatitude { get; set; }
        
        public bool FloodPlane { get; set; }

        public int District { get; set; }

        public string ParcelNumber { get; set; }

        public int RealKey { get; set; }

        public string QPublicLink { get; set; }

        public string GoogleMapsLink { get; set; }

        public string PictureLink { get; set; }

        public string DirectionsLink { get; set; }

        public int? AccessoryKey { get; set; }

        public int? MobileHomeKey { get; set; }

        public string ZipCode { get; set; }

        public string Zoning { get; set; }

        public string PointType { get; set; }

        public string PowerCompany { get; set; }

        public string SuffixDirection { get; set; }

        public string PrefixCardinalDirection { get; set; }

        public string Community { get; set; }

        public string Muncipality { get; set; }
    }
}
