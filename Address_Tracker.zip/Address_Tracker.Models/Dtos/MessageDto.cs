﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Models.Dtos
{
    public class MessageDto
    {
        public int Id { get; set; }

        public string Subject { get; set; }

        public bool IsRead { get; set; }

        public DateTime DateSent { get; set; }

        public string SenderName { get; set; }
    }
}
