﻿namespace Address_Tracker.Models.Dtos
{
    public class ReportDto
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string DisplayName { get; set; }
    }
}