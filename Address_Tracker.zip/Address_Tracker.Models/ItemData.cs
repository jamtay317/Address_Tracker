﻿using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    public abstract class ItemData : ModelBase
    {
        public string Name { get; set; }
    }
}