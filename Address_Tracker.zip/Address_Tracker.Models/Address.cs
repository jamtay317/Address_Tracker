﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("Address")]
    public class Address:ModelBase
    {
        public int HouseNumber { get; set; }

        public string AppartmentNumber { get; set; }

        public string AddressStreetName { get; set; }

        public string NameOfBusiness { get; set; }

        public int? CommunityId { get; set; }

        public string County { get; set; }

        public int? EsnNumber { get; set; }

        public string SubDivision { get; set; }

        public string PropertyDescription { get; set; }

        public int? PrefixCardinalDirectionId { get; set; }

        public int? SuffixDirectionId { get; set; }

        public int StreetNumber { get; set; }

        public string RoadType { get; set; }

        public string FirstPartOfStreetName { get; set; }

        public string StreetName { get; set; }

        public decimal? Longitude { get; set; }

        public decimal? Latitude { get; set; }

        public int? PowerCompanyId { get; set; }

        public string TotalAddress { get; set; }

        public int? ZipCodeId { get; set; }

        public string Notes { get; set; }

        public int? PointTypeId { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public decimal? OldLongitude { get; set; }

        public decimal? OldLatitude { get; set; }

        public int? ZoningId { get; set; }

        public bool FloodPlane { get; set; }

        public int? District { get; set; }

        public string ParcelNumber { get; set; }

        public int? RealKey { get; set; }

        public string QPublicLink { get; set; }

        public string GoogleMapsLink { get; set; }

        public string DirectionsLink { get; set; }

        public string  PictureLink { get; set; }

        public int? AccessoryKey { get; set; }

        public int? MobileHomeKey { get; set; }

        public ZipCode ZipCode { get; set; }

        public Zoning Zoning { get; set; }

        public PointType PointType { get; set; }

        public PowerCompany PowerCompany { get; set; }

        public Direction SuffixDirection { get; set; }

        public Direction PrefixCardinalDirection { get; set; }

        public Community Community { get; set; }

        public int? MuncipalityId { get; set; }

        [NotMapped]
        public string CommunityName => Community?.Name;

        [NotMapped]
        public string PrefixCardinalDirectionName => PrefixCardinalDirection?.Name;

        [NotMapped]
        public string SuffixDirectionName => SuffixDirection?.Name;

        [NotMapped]
        public string PowerCompanyName => PowerCompany?.Name;

        [NotMapped]
        public string PointTypeName => PointType?.Name;

        [NotMapped]
        public string ZoningName => Zoning?.Name;

        [NotMapped]
        public string ZipCodeName => ZipCode?.Name;


    }
}