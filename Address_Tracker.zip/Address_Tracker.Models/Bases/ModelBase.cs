﻿using Address_Tracker.Models.Interfaces;

namespace Address_Tracker.Models.Bases
{
    public abstract class ModelBase:IEntity
    {
        public int Id { get; set; }
    }
}