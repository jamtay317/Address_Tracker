﻿using System.ComponentModel.DataAnnotations.Schema;
using Address_Tracker.Models.Bases;

namespace Address_Tracker.Models
{
    [Table("Report")]
    public class Report:ModelBase
    {
        public string Name { get; set; }

        public string DisplayName { get; set; }

        public string FilePath { get; set; }

        public string ProcedureName { get; set; }

        public string DataSourceName { get; set; }

    }
}