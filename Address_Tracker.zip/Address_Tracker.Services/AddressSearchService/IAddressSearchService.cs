﻿using System.Collections.Generic;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;

namespace Address_Tracker.Services.AddressSearchService
{
    public interface IAddressSearchService
    {
        IEnumerable<AddressResultDto> Search(AddressSearchDto addressSearchDto);

        IEnumerable<AddressDto> SearchAddressJoinedToAllTables(AddressSearchDto addressSearchDto);
    }
}