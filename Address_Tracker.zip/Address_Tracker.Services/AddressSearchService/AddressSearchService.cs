﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;
using System.Data.Entity;
using System.Data.SqlClient;
using Address_Tracker.Data.ExtensionMethods;
using Address_Tracker.Services.AdoSqlService;

namespace Address_Tracker.Services.AddressSearchService
{
    public class AddressSearchService:IAddressSearchService
    {
        private readonly IAdoSqlService _adoSqlService;


        public AddressSearchService(
            IAdoSqlService adoSqlService
           )
        {
            _adoSqlService = adoSqlService;
        }

        public IEnumerable<AddressResultDto> Search(AddressSearchDto addressSearchDto)
        {
            var sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("@PageSize", SqlDbType.Int).AddValue(addressSearchDto.PageSize), 
                new SqlParameter("@Start", SqlDbType.Int).AddValue(addressSearchDto.Start), 
                new SqlParameter("@StreetName",SqlDbType.NVarChar).AddValue(addressSearchDto.StreetName??String.Empty),
                new SqlParameter("@Notes",SqlDbType.NVarChar).AddValue(addressSearchDto.Notes??String.Empty),
                new SqlParameter("@ParcelNumber",SqlDbType.NVarChar).AddValue(addressSearchDto.ParcelNumber??String.Empty),
                new SqlParameter("@ZoningCode",SqlDbType.NVarChar).AddValue(addressSearchDto.ZoningCode??String.Empty),
                new SqlParameter("@HouseNumber",SqlDbType.NVarChar).AddValue(addressSearchDto.HouseNumber.ToString()??String.Empty),
                new SqlParameter("@County",SqlDbType.NVarChar).AddValue(addressSearchDto.County??String.Empty),
                new SqlParameter("@Municipality",SqlDbType.NVarChar).AddValue(addressSearchDto.Municipality??String.Empty),
                new SqlParameter("@SubDivision",SqlDbType.NVarChar).AddValue(addressSearchDto.SubDivision??String.Empty),
                new SqlParameter("@Community", SqlDbType.NVarChar).AddValue(addressSearchDto.Community),
                new SqlParameter("@PointType", SqlDbType.NVarChar).AddValue(addressSearchDto.PointType)
            };

            if (addressSearchDto.Esn != null)
            {
                sqlParameters.Add(new SqlParameter("@Esn", SqlDbType.Int).AddValue(addressSearchDto.Esn));
            }

            if (addressSearchDto.UniqueId != null)
            {
                sqlParameters.Add(new SqlParameter("@UniqueId",SqlDbType.Int).AddValue(addressSearchDto.UniqueId));
            }

            if (addressSearchDto.District != null)
            {
                sqlParameters.Add(new SqlParameter("@District", SqlDbType.Int).AddValue(addressSearchDto.District));
            }


            var dataTable = _adoSqlService.ExecuteStoredProcedure("AddressSearch", sqlParameters.ToArray());
            return dataTable.ToList<AddressResultDto>();
        }

        public IEnumerable<AddressDto> SearchAddressJoinedToAllTables(AddressSearchDto addressSearchDto)
        {
            var sqlParameters = new List<SqlParameter>
            {
                new SqlParameter("@PageSize", SqlDbType.Int).AddValue(addressSearchDto.PageSize),
                new SqlParameter("@Start", SqlDbType.Int).AddValue(addressSearchDto.Start),
                new SqlParameter("@StreetName",SqlDbType.NVarChar).AddValue(addressSearchDto.StreetName??String.Empty),
                new SqlParameter("@Notes",SqlDbType.NVarChar).AddValue(addressSearchDto.Notes??String.Empty),
                new SqlParameter("@ParcelNumber",SqlDbType.NVarChar).AddValue(addressSearchDto.ParcelNumber??String.Empty),
                new SqlParameter("@ZoningCode",SqlDbType.NVarChar).AddValue(addressSearchDto.ZoningCode??String.Empty),
                new SqlParameter("@HouseNumber",SqlDbType.NVarChar).AddValue(addressSearchDto.HouseNumber.ToString()??String.Empty),
                new SqlParameter("@County",SqlDbType.NVarChar).AddValue(addressSearchDto.County??String.Empty),
                new SqlParameter("@Municipality",SqlDbType.NVarChar).AddValue(addressSearchDto.Municipality??String.Empty),
                new SqlParameter("@SubDivision",SqlDbType.NVarChar).AddValue(addressSearchDto.SubDivision??String.Empty),
            };

            if (addressSearchDto.Esn != null)
            {
                sqlParameters.Add(new SqlParameter("@Esn", SqlDbType.Int).AddValue(addressSearchDto.Esn));
            }

            if (addressSearchDto.UniqueId != null)
            {
                sqlParameters.Add(new SqlParameter("@UniqueId", SqlDbType.Int).AddValue(addressSearchDto.UniqueId));
            }

            if (addressSearchDto.District != null)
            {
                sqlParameters.Add(new SqlParameter("@District", SqlDbType.Int).AddValue(addressSearchDto.District).AddValue(addressSearchDto.UniqueId));
            }


            var dataTable = _adoSqlService.ExecuteStoredProcedure("SearchAddressJoinedToAllTables", sqlParameters.ToArray());
            return dataTable.ToList<AddressDto>();
        }
    }
}
