﻿using System;
using System.Linq;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using ASP.SystemSettingsService;

namespace ASP.Session
{
    public class SessionService:ISessionService
    {
        private readonly IRepository<ActiveSession> _sessionRepository;
        private readonly ISystemSettingsService _systemSettingsService;

        public SessionService(IRepository<ActiveSession> sessionRepository, ISystemSettingsService systemSettingsService)
        {
            _sessionRepository = sessionRepository;
            _systemSettingsService = systemSettingsService;
        }
        public ActiveSession UpdateOrStartActiveSession(string username)
        {
            var session = _sessionRepository.Get().FirstOrDefault(x => x.Username == username);
            var timeoutDays = _systemSettingsService.SystemSettings.SessionTimeOutInDays;

            if (session==null || session.Expires < DateTime.Today )
            {
                if (session != null)
                {
                    _sessionRepository.Delete(session.Id);
                }
                session = AddSession(username);
            }
            else
            {
                session=UpdateSession(session);
            }

            return session;
        }

        public void Logout(string username)
        {
            var session = _sessionRepository.Get().FirstOrDefault(x => x.Username == username);
            if (session != null)
            {
                _sessionRepository.Delete(session.Id);
            }
        }

        private ActiveSession UpdateSession(ActiveSession session)
        {
            session.LastLogin = DateTime.Today;
            _sessionRepository.Patch(session);
            return session;
        }

        private ActiveSession AddSession(string username)
        {
            var session = ActiveSession.Create(username);
            session.Expires = DateTime.Today.AddDays(_systemSettingsService.SystemSettings.SessionTimeOutInDays);
            _sessionRepository.Post(session);
            return session;
        }

        
    }
}