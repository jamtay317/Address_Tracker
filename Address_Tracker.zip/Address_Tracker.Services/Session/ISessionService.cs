﻿using Address_Tracker.Models;

namespace ASP.Session
{
    public interface ISessionService
    {
        ActiveSession UpdateOrStartActiveSession(string username);

        void Logout(string username);
    }
}