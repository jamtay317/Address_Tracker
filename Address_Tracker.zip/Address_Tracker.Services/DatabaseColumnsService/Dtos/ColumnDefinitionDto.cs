﻿namespace Address_Tracker.Services.DatabaseColumnsService.Dtos
{
    public class ColumnDefinitionDto
    {
        public ColumnDefinitionDto(string currentName, string exportName)
        {
            CurrentName = currentName;
            ExportName = exportName;
        }
        public string CurrentName { get; }

        public string ExportName { get; }
    }
}