﻿using System.Collections.Generic;
using Address_Tracker.Services.DatabaseColumnsService.Dtos;

namespace Address_Tracker.Services.DatabaseColumnsService
{
    public interface IDatabaseColumnDefinition
    {
        /// <summary>
        /// Column Definitions is key value, the key is the CurrentName, the value is a ColumnDefinitionDto
        /// </summary>
        Dictionary<string, ColumnDefinitionDto> ColumnDefinitions { get; }

        string GetCurrentName(string exportName);

        string GetExportName(string currentName);
    }
}