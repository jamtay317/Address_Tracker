﻿using System;
using System.Collections.Generic;
using System.Linq;
using Address_Tracker.Data.Logger;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Services.DatabaseColumnsService.Dtos;

namespace Address_Tracker.Services.DatabaseColumnsService
{
    public class DatabaseColumnDefinition:IDatabaseColumnDefinition
    {
        private readonly IRepository<DatabaseColumnName> _databaseColumnNameRepository;

        public DatabaseColumnDefinition(IRepository<DatabaseColumnName> databaseColumnNameRepository)
        {
            _databaseColumnNameRepository = databaseColumnNameRepository;
            ColumnDefinitions = new Dictionary<string, ColumnDefinitionDto>();
            LoadData();
        }
        public Dictionary<string, ColumnDefinitionDto> ColumnDefinitions { get; }
        public string GetCurrentName(string exportName)
        {
            var dictionaryItemsWithExportName = ColumnDefinitions.Single(x => x.Value.ExportName == exportName);
            return dictionaryItemsWithExportName.Key;
        }

        public string GetExportName(string currentName)
        {
            if (!ColumnDefinitions.ContainsKey(currentName))
            {
                AddressLogger.LogMessage($"Column Definitions doesnt contian a definition for {currentName}");
                throw new NullReferenceException();
            }

            return ColumnDefinitions[currentName].ExportName;
        }

        private void LoadData()
        {
            var listOfColumns = _databaseColumnNameRepository
                .Get()
                .ToList()
                .Select(x => new ColumnDefinitionDto(x.CurrentName, x.ExportName));

            foreach (var column in listOfColumns)
            {
                ColumnDefinitions.Add(column.CurrentName, column);
            }

        }
    }
}