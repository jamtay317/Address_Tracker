﻿using System.Data;
using System.Data.SqlClient;

namespace Address_Tracker.Services.AdoSqlService
{

    public interface IAdoSqlService
    {
        void ExecuteNonQuery(string name, params SqlParameter[] parameters);

        DataTable ExecuteStoredProcedure(string name, params SqlParameter[] parameters);
    }
}