﻿using System.Data;
using System.Data.SqlClient;
using Address_Tracker.Data.ConfigurationServices;

namespace Address_Tracker.Services.AdoSqlService
{
    public class AdoSqlService:IAdoSqlService
    {
        private readonly IConfigurationService _configurationService;

        public AdoSqlService(IConfigurationService configurationService)
        {
            _configurationService = configurationService;
        }
        public void ExecuteNonQuery(string name, params SqlParameter[] parameters)
        {
            var mode = _configurationService.AppSetting("mode");
            var connectionString = _configurationService.ConnectionString($"{mode}ConnectionString");
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                using (var command = new SqlCommand(name,sqlConnection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    command.ExecuteNonQuery();
                }
            }
        }

        public DataTable ExecuteStoredProcedure(string name, params SqlParameter[] parameters)
        {
            var dataTable = new DataTable();
            var mode = _configurationService.AppSetting("mode");
            var connectionString = _configurationService.ConnectionString($"{mode}ConnectionString");
            using (var sqlConnection = new SqlConnection(connectionString))
            {
                sqlConnection.Open();
                using (var command = new SqlCommand(name,sqlConnection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddRange(parameters);
                    using (var dataAdapter = new SqlDataAdapter(command))
                    {
                        dataAdapter.Fill(dataTable);
                    }
                }
            }

            return dataTable;
        }
    }
}