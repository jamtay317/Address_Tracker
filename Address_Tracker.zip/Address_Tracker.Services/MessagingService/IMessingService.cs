﻿namespace ASP.MessagingService
{
    public interface IMessagingService
    {
        void Send(string subject, string message);
    }
}