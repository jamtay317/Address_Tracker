﻿using System;
using System.Net;
using System.Net.Mail;
using Address_Tracker.Data.Logger;
using ASP.SystemSettingsService;

namespace ASP.MessagingService
{
    public class MessagingService:IMessagingService
    {
        private readonly ISystemSettingsService _systemSettingsService;

        public MessagingService(ISystemSettingsService systemSettingsService)
        {
            _systemSettingsService = systemSettingsService;
        }
        public void Send(string subject, string message)
        {
            var completeMessage = BuildMessage(message);

            var mailMessage = new MailMessage();
            mailMessage.To.Add(new MailAddress(_systemSettingsService.SystemSettings.ReciverEmailAddress,"James Tays"));
            mailMessage.From = new MailAddress(_systemSettingsService.SystemSettings.SenderEmailAddress, "James Tays");
            mailMessage.Subject = subject;
            mailMessage.Body = completeMessage;
            mailMessage.IsBodyHtml = false;


            var client = new SmtpClient();
            client.UseDefaultCredentials = false;
            client.Credentials = new NetworkCredential(_systemSettingsService.SystemSettings.SenderEmailAddress, _systemSettingsService.SystemSettings.SenderEmailPassword);
            client.Port = _systemSettingsService.SystemSettings.SmtpPort;
            client.Host = _systemSettingsService.SystemSettings.SmtpHost;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.EnableSsl = false;
            try
            {
                client.Send(mailMessage);
            }
            catch (Exception e)
            {
                AddressLogger.LogError("Faild Sending Email",e);
            }
        }

        private static string BuildMessage(string message)
        {
            var returnMessage =
                $@"You Have a new message from Address Tracker, the message states: {Environment.NewLine}"
                + $@" ""{message}"" {Environment.NewLine}"
                + $@"Please login to Address Tracker to view details";
            return returnMessage;
        }
    }
}