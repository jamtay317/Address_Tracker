﻿using System.Linq;
using Address_Tracker.Data.Context.Interfaces;
using Address_Tracker.Models;

namespace ASP.SystemSettingsService
{
    public class SystemSettingsService:ISystemSettingsService
    {
        private readonly IAddressContext _addressContext;

        public SystemSettingsService(IAddressContext addressContext)
        {
            _addressContext = addressContext;
        }

        public SystemSetting SystemSettings => _addressContext.SystemSettings.Single();
    }
}