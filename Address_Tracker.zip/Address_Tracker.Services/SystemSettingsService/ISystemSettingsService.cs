﻿using Address_Tracker.Models;

namespace ASP.SystemSettingsService
{
    public interface ISystemSettingsService
    {
        SystemSetting SystemSettings { get; }
    }
}