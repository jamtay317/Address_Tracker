﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Services.AddressService
{
    public interface IAddressService
    {
        void DeleteAllAddresses();
        void ImportCsv(string csv);
        void CleanUpFiles(string tempfilePath);
    }
}
