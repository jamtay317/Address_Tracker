﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Address_Tracker.Data.ExtensionMethods;
using Address_Tracker.Data.Logger;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.AdoSqlService;
using Address_Tracker.Services.FileServices;
using AutoMapper;

namespace Address_Tracker.Services.AddressService
{
    public class AddressService:IAddressService
    {
        private readonly IRepository<Address> _addressRepository;
        private readonly IAdoSqlService _adoSqlService;
        private readonly ICsvService _csvService;
        private readonly IRepository<Zoning> _zoneingRepository;
        private readonly IRepository<PointType> _pointTypeRepository;
        private readonly IRepository<ZipCode> _zipRepository;
        private readonly IRepository<PowerCompany> _powerCompanyRepository;
        private readonly IRepository<Municipality> _municipalityRepository;
        private readonly IRepository<Community> _communityRepository;
        private readonly IRepository<Direction> _directionRepository;

        public AddressService(IRepository<Address> addressRepository, 
            IAdoSqlService adoSqlService,
            ICsvService csvService,
            IRepository<Zoning> zoneingRepository,
            IRepository<PointType> pointTypeRepository,
            IRepository<ZipCode> zipRepository,
            IRepository<PowerCompany> powerCompanyRepository,
            IRepository<Municipality> municipalityRepository,
            IRepository<Community> communityRepository,
            IRepository<Direction> directionRepository)
        {
            _addressRepository = addressRepository;
            _adoSqlService = adoSqlService;
            _csvService = csvService;
            _zoneingRepository = zoneingRepository;
            _pointTypeRepository = pointTypeRepository;
            _zipRepository = zipRepository;
            _powerCompanyRepository = powerCompanyRepository;
            _municipalityRepository = municipalityRepository;
            _communityRepository = communityRepository;
            _directionRepository = directionRepository;
        }


        public void DeleteAllAddresses()
        {
            AddressLogger.LogMessage($"Deleting all addresses at: {DateTime.Now}:");
            _adoSqlService.ExecuteNonQuery("DeleteAllAddresses");
        }

        public void ImportCsv(string csv)
        {
            AddressLogger.LogMessage($"Parsing csv");
            var addressDtos = _csvService.Deserialize<AddressDto>(csv);
            AddressLogger.LogMessage("All Addresses Parsed");

            var communities = _communityRepository.Get().ToList();
            var directions = _directionRepository.Get().ToList();
            var municipalities = _municipalityRepository.Get().ToList();
            var pointTypes = _pointTypeRepository.Get().ToList();
            var powerCompanies = _powerCompanyRepository.Get().ToList();
            var zipCodes = _zipRepository.Get().ToList();
            var zonings = _zoneingRepository.Get().ToList();

            var addresses = new List<Address>();
            foreach (var addressDto in addressDtos)
            {
                addresses.Add(GetAddress(addressDto, communities, directions, municipalities, pointTypes, powerCompanies, zipCodes, zonings));
            }


            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var chunkedAddresses = SplitAddressesIntoChunks(limit: 1000, addresses:addresses);

            foreach (var chunkedAddress in chunkedAddresses)
            {
                foreach (var address in chunkedAddress)
                {
                    var parmaters = new[]
                    {
                        new SqlParameter("@HouseNumber",SqlDbType.Int).AddValue(address.HouseNumber),
                        new SqlParameter("@AppartmentNumber",SqlDbType.NVarChar).AddValue(address.AppartmentNumber),
                        new SqlParameter("@NameOfBusiness",SqlDbType.NVarChar).AddValue(address.NameOfBusiness),
                        new SqlParameter("@CommunityId",SqlDbType.Int).AddValue(address.CommunityId),
                        new SqlParameter("@County",SqlDbType.NVarChar).AddValue(address.County),
                        new SqlParameter("@EsnNumber",SqlDbType.Int).AddValue(address.EsnNumber),
                        new SqlParameter("@SubDivision",SqlDbType.NVarChar).AddValue(address.SubDivision),
                        new SqlParameter("@PropertyDescription",SqlDbType.NVarChar).AddValue(address.PropertyDescription??String.Empty),
                        new SqlParameter("@PrefixCardinalDirectionId",SqlDbType.Int).AddValue(address.PrefixCardinalDirectionId),
                        new SqlParameter("@SuffixDirectionId",SqlDbType.Int).AddValue(address.SuffixDirectionId),
                        new SqlParameter("@StreetNumber",SqlDbType.Int).AddValue(address.StreetNumber),
                        new SqlParameter("@RoadType",SqlDbType.NVarChar).AddValue(address.RoadType),
                        new SqlParameter("@StreetName",SqlDbType.NVarChar).AddValue(address.StreetName),
                        new SqlParameter("@Longitude",SqlDbType.Decimal).AddValue(address.Longitude),
                        new SqlParameter("@Latitude",SqlDbType.Decimal).AddValue(address.Latitude),
                        new SqlParameter("@PowerCompanyId",SqlDbType.Int).AddValue(address.PowerCompanyId),
                        new SqlParameter("@ZipCodeId",SqlDbType.Int).AddValue(address.ZipCodeId),
                        new SqlParameter("@Notes",SqlDbType.NVarChar).AddValue(address.Notes),
                        new SqlParameter("@PointTypeId",SqlDbType.Int).AddValue(address.PointTypeId),
                        new SqlParameter("@LastName",SqlDbType.NVarChar).AddValue(address.LastName),
                        new SqlParameter("@FirstName",SqlDbType.NVarChar).AddValue(address.FirstName),
                        new SqlParameter("@MiddleName",SqlDbType.NVarChar).AddValue(address.MiddleName),
                        new SqlParameter("@OldLongitude",SqlDbType.Decimal).AddValue(address.OldLongitude),
                        new SqlParameter("@OldLatitude",SqlDbType.Decimal).AddValue(address.OldLatitude),
                        new SqlParameter("@ZoningId",SqlDbType.Int).AddValue(address.ZoningId),
                        new SqlParameter("@FloodPlane",SqlDbType.Bit).AddValue(address.FloodPlane),
                        new SqlParameter("@District",SqlDbType.Int).AddValue(address.District),
                        new SqlParameter("@ParcelNumber",SqlDbType.NVarChar).AddValue(address.ParcelNumber),
                        new SqlParameter("@RealKey",SqlDbType.Int).AddValue(address.RealKey),
                        new SqlParameter("@QPublicLink",SqlDbType.NVarChar).AddValue(address.QPublicLink),
                        new SqlParameter("@GoogleMapsLink",SqlDbType.NVarChar).AddValue(address.GoogleMapsLink),
                        new SqlParameter("@DirectionsLink",SqlDbType.NVarChar).AddValue(address.DirectionsLink),
                        new SqlParameter("@AccessoryKey",SqlDbType.Int).AddValue(address.AccessoryKey),
                        new SqlParameter("@MobileHomeKey",SqlDbType.Int).AddValue(address.MobileHomeKey),
                        new SqlParameter("@MuncipalityId",SqlDbType.Int).AddValue(address.MuncipalityId),
                        new SqlParameter("@TotalAddress",SqlDbType.NVarChar).AddValue(address.TotalAddress),
                        new SqlParameter("@FirstPartOfStreetName",SqlDbType.NVarChar).AddValue(address.FirstPartOfStreetName),
                        new SqlParameter("@AddressStreetName",SqlDbType.NVarChar).AddValue(address.AddressStreetName),
                        new SqlParameter("@PictureLink",SqlDbType.NVarChar).AddValue(address.PictureLink),
                    };
                    _adoSqlService.ExecuteNonQuery("InsertAddress", parmaters);
                }
            }

            stopwatch.Stop();
            AddressLogger.LogMessage($"It took {stopwatch.Elapsed.TotalSeconds} Seconds to insert separately");

        }

        public void CleanUpFiles(string tempfilePath)
        {
            var directoryInfo = new DirectoryInfo(tempfilePath);
            foreach (var fileInfo in directoryInfo.GetFiles())
            {
                fileInfo.Delete();
            }
        }



        private Address GetAddress(AddressDto addressDto, 
            List<Community> communities, 
            List<Direction> directions,
            List<Municipality> municipalities, 
            List<PointType> pointTypes, 
            List<PowerCompany> powerCompanies, 
            List<ZipCode> zipCodes, 
            List<Zoning> zonings)
        {
            var address = new Address()
            {
                HouseNumber = addressDto.HouseNumber,
                AppartmentNumber = addressDto.AppartmentNumber,
                NameOfBusiness = addressDto.NameOfBusiness,
                County = addressDto.County,
                FirstPartOfStreetName = addressDto.FirstPartOfStreetName,
                EsnNumber = addressDto.EsnNumber,
                SubDivision = addressDto.SubDivision,
                PropertyDescription = addressDto.PropertyDescription,
                StreetNumber = addressDto.StreetNumber,
                RoadType = addressDto.RoadType,
                StreetName = addressDto.StreetName,
                Longitude = addressDto.Longitude,
                Latitude = addressDto.Latitude,
                Notes = addressDto.Notes,
                LastName = addressDto.LastName,
                FirstName = addressDto.FirstName,
                MiddleName = addressDto.MiddleName,
                OldLatitude = addressDto.OldLatitude,
                OldLongitude = addressDto.OldLongitude,
                FloodPlane = addressDto.FloodPlane,
                District = addressDto.District,
                ParcelNumber = addressDto.ParcelNumber,
                RealKey = addressDto.RealKey,
                QPublicLink = addressDto.QPublicLink,
                GoogleMapsLink = addressDto.GoogleMapsLink,
                DirectionsLink = addressDto.DirectionsLink,
                AccessoryKey = addressDto.AccessoryKey,
                MobileHomeKey = addressDto.MobileHomeKey,
                TotalAddress = addressDto.TotalAddress,
                AddressStreetName = addressDto.AddressStreetName,
                PictureLink = addressDto.PictureLink
            };
            address.CommunityId = communities.FirstOrDefault(x => x.Name.ToLower() == addressDto.Community.ToLower())?.Id;
            address.SuffixDirectionId = directions.FirstOrDefault(x => x.Name.ToLower() == addressDto.SuffixDirection?.ToLower())?.Id;
            address.PrefixCardinalDirectionId = directions.FirstOrDefault(x => x.Name.ToLower() == addressDto.SuffixDirection?.ToLower())?.Id;
            address.MuncipalityId = municipalities.FirstOrDefault(x => x.Name.ToLower() == addressDto.Muncipality?.ToLower())?.Id;
            address.PointTypeId = pointTypes.FirstOrDefault(x => x.Name.ToLower() == addressDto.PointType?.ToLower())?.Id;
            address.ZipCodeId = zipCodes.FirstOrDefault(x => x.Name.ToLower() == addressDto.ZipCode?.ToLower())?.Id;
            address.ZoningId = zonings.FirstOrDefault(x => x.Name.ToLower() == addressDto.Zoning?.ToLower())?.Id;

            return address;
        }

        private IEnumerable<IEnumerable<Address>> SplitAddressesIntoChunks(int limit, IEnumerable<Address> addresses)
        {
            var totalChunks = addresses.Count() / limit + 1;
            var chunks = new List<IEnumerable<Address>>();

            for (int i = 0; i < totalChunks; i++)
            {
                var totalAddressesToSkip = i * limit;
                var chunk = addresses.Skip(totalAddressesToSkip).Take(limit);
                chunks.Add(chunk);
            }

            return chunks;
        }
    }
}