﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.UI.WebControls;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.AdoSqlService;
using Microsoft.Reporting.WebForms;
using Report = Address_Tracker.Models.Report;

namespace Address_Tracker.Services.Reports.Service
{
    public class ReportService:IReportService
    {
        private readonly IRepository<Report> _reportRepository;
        private readonly IAdoSqlService _adoSqlService;

        public ReportService(IRepository<Models.Report> reportRepository, IAdoSqlService adoSqlService)
        {
            _reportRepository = reportRepository;
            _adoSqlService = adoSqlService;
        }

        public ReportViewer GetReport(int reportId, string basePath)
        {
            // get report from database
            var report = _reportRepository.Get(reportId);
            var reportViewer = new ReportViewer();

            if (report == null)
            {
                throw new NullReferenceException("Report could not be found");
            }

            // create report viewer
                
            reportViewer.ProcessingMode = ProcessingMode.Local;
            reportViewer.SizeToReportContent = true;
            reportViewer.Width = Unit.Percentage(900);
            reportViewer.Height = Unit.Percentage(900);

            // get data for report
            var dataTable = _adoSqlService.ExecuteStoredProcedure(report.ProcedureName);

            // fill report data source
            var reportPath = Path.Combine(basePath,report?.FilePath??String.Empty);

            reportViewer.LocalReport.ReportPath = reportPath;
            reportViewer.LocalReport.DataSources.Add(new ReportDataSource(report.DataSourceName, dataTable));

            // return report viewer
            return reportViewer;
        }

        public IEnumerable<ReportDto> GetReportDtos()
        {
            var reports = _reportRepository.Get()
                .Select(x => new ReportDto() {Id = x.Id, Name = x.Name, DisplayName = x.DisplayName})
                .ToList();

            return reports;
        }
    }
}