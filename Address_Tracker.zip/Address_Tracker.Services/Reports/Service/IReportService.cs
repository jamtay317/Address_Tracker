﻿using System.Collections.Generic;
using System.Data;
using Address_Tracker.Models.Dtos;
using Microsoft.Reporting.WebForms;

namespace Address_Tracker.Services.Reports.Service
{
    public interface IReportService
    {
        ReportViewer GetReport(int reportId, string basePath);

        IEnumerable<ReportDto> GetReportDtos();
    }
}