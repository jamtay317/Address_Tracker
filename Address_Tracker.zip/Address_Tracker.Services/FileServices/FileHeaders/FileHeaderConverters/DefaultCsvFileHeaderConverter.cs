﻿namespace Address_Tracker.Services.FileServices.FileHeaders.FileHeaderConverters
{
    public class DefaultCsvFileHeaderConverter:ICsvFileHeaderConverter
    {
        public string GetHeader(string propertyName)
        {
            return propertyName;
        }
    }
}