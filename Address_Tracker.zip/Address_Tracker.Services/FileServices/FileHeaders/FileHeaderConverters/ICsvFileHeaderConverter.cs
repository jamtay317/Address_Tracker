﻿namespace Address_Tracker.Services.FileServices.FileHeaders.FileHeaderConverters
{
    public interface ICsvFileHeaderConverter
    {
        string GetHeader(string propertyName);
    }
}