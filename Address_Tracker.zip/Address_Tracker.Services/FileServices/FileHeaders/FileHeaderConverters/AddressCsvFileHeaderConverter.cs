﻿using System;
using Address_Tracker.Services.DatabaseColumnsService;

namespace Address_Tracker.Services.FileServices.FileHeaders.FileHeaderConverters
{
    public class AddressCsvFileHeaderConverter:ICsvFileHeaderConverter
    {
        private readonly IDatabaseColumnDefinition _databaseColumnDefinition;

        public AddressCsvFileHeaderConverter(IDatabaseColumnDefinition databaseColumnDefinition)
        {
            _databaseColumnDefinition = databaseColumnDefinition;
        }
        public string GetHeader(string propertyName)
        {
            return _databaseColumnDefinition.GetExportName(propertyName);
        }
    }
}