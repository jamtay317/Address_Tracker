﻿using System;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.DatabaseColumnsService;
using Address_Tracker.Services.FileServices.FileHeaders.FileHeaderConverters;

namespace Address_Tracker.Services.FileServices.FileHeaders
{
    public class CsvFileHeaderFactory:ICsvFileHeaderFactory
    {
        private readonly IDatabaseColumnDefinition _databaseColumnDefinition;

        public CsvFileHeaderFactory(IDatabaseColumnDefinition databaseColumnDefinition)
        {
            _databaseColumnDefinition = databaseColumnDefinition;
        }

        public ICsvFileHeaderConverter GetFileHeaderConverter(Type objecType)
        {
            ICsvFileHeaderConverter converter = null;

            if (typeof(AddressDto) == objecType)
            {
                converter = new AddressCsvFileHeaderConverter(_databaseColumnDefinition);
            }
            else
            {
                converter = new DefaultCsvFileHeaderConverter();
            }

            return converter;
        }
    }
}