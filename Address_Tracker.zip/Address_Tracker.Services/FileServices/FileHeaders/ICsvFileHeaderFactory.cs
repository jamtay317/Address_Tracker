﻿using System;
using Address_Tracker.Services.FileServices.FileHeaders.FileHeaderConverters;

namespace Address_Tracker.Services.FileServices.FileHeaders
{
    public interface ICsvFileHeaderFactory
    {
        ICsvFileHeaderConverter GetFileHeaderConverter(Type objecType);
    }
}