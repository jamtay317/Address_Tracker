﻿using System;
using System.Reflection;
using Address_Tracker.Services.FileServices.PropertySetters.Interfaces;

namespace Address_Tracker.Services.FileServices.PropertySetters
{
    public class YesNoCsvPropertySetter : ICsvPropertySetterChainOfResponsibilty
    {
        public YesNoCsvPropertySetter()
        {
            Sucesser = new EndOfChainCsvPropertySetter();
        }
        public ICsvPropertySetterChainOfResponsibilty Sucesser { get; }
        public void SetValue<T>(ref T objectThatContainsProperty, object value, Type propertyType, PropertyInfo property)
        {
            if (value.ToString().ToLower() == "no" || value.ToString().ToLower() == "yes")
            {
                value = (value.ToString().ToLower() == "yes") ? true : false;
                property.SetValue(objectThatContainsProperty, value, null);
                return;
            }
            Sucesser.SetValue(ref objectThatContainsProperty,value,propertyType, property);
        }
    }
}