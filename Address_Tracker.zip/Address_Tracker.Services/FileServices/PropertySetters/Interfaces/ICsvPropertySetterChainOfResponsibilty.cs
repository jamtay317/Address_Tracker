﻿using System;
using System.Reflection;

namespace Address_Tracker.Services.FileServices.PropertySetters.Interfaces
{
    public interface ICsvPropertySetterChainOfResponsibilty
    {
        ICsvPropertySetterChainOfResponsibilty Sucesser { get; }

        void SetValue<T>(ref T objectThatContainsProperty, object value, Type propertyType, PropertyInfo property);
    }
}