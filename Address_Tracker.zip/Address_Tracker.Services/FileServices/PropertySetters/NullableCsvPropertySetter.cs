﻿using System;
using System.Reflection;
using Address_Tracker.Services.FileServices.PropertySetters.Interfaces;

namespace Address_Tracker.Services.FileServices.PropertySetters
{
    public class NullableCsvPropertySetter:ICsvPropertySetterChainOfResponsibilty
    {
        public NullableCsvPropertySetter()
        {
            Sucesser = new YesNoCsvPropertySetter();
        }
        public ICsvPropertySetterChainOfResponsibilty Sucesser { get; }
        public void SetValue<T>(ref T objectThatContainsProperty, object value, Type propertyType, PropertyInfo property)
        {
            if(property.PropertyType.IsGenericType &&
               property.PropertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
            {
                property.SetValue(objectThatContainsProperty, Convert.ChangeType(value, Nullable.GetUnderlyingType(property.PropertyType)), null);
                return;
            }
            Sucesser.SetValue(ref objectThatContainsProperty,value,propertyType,property);
        }
    }
}