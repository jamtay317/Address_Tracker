﻿using System;
using System.Reflection;
using Address_Tracker.Services.FileServices.PropertySetters.Interfaces;

namespace Address_Tracker.Services.FileServices.PropertySetters
{
    public class EndOfChainCsvPropertySetter:ICsvPropertySetterChainOfResponsibilty
    {
        public ICsvPropertySetterChainOfResponsibilty Sucesser { get; }
        public void SetValue<T>(ref T objectThatContainsProperty, object value, Type propertyType, PropertyInfo property)
        {
            property.SetValue(objectThatContainsProperty,Convert.ChangeType(value,propertyType),null);
        }
    }
}