﻿using System.Collections.Generic;
using Address_Tracker.Models;

namespace Address_Tracker.Services.FileServices
{
    public interface ICsvService
    {
        IEnumerable<T> Deserialize<T>(string csv) where T : class, new();

        string Serialize<T>(IEnumerable<T> objects);
    }
}