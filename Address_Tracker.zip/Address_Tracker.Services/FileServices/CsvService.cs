﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Address_Tracker.Data.Logger;
using Address_Tracker.Models;
using Address_Tracker.Services.FileServices.FileHeaders;
using Address_Tracker.Services.FileServices.PropertySetters;

namespace Address_Tracker.Services.FileServices
{
    public class CsvService : ICsvService
    {
        private readonly ICsvFileHeaderFactory _csvFileHeaderFactory;
        private StringBuilder _stringBuilder;
        private const string Comma = ",";
        private const string Semicolon = ";";

        public CsvService(ICsvFileHeaderFactory csvFileHeaderFactory)
        {
            _csvFileHeaderFactory = csvFileHeaderFactory;
        }

        public IEnumerable<T> Deserialize<T>(string csv) 
            where T:class,new()
        {
            var listOfT = new List<T>();
            var lines = SplitIntoLines(csv);
            var propertyNames = GetPropertyNames(lines[0]);

            //Remove first line because it contains propery names and we dont want to add to db
            lines.RemoveAt(0);

            try
            {
                foreach (var line in lines)
                {
                    var t = DeserializeLine<T>(line, propertyNames);
                    listOfT.Add(t);
                }
            }
            catch (Exception e)
            {
                AddressLogger.LogError("Error while parsing lines:", e);
                throw;
            }

            return listOfT;
        }

        public string Serialize<T>(IEnumerable<T> objects)
        {
            _stringBuilder = new StringBuilder();
            //get headers
            AddAllHeaders(typeof(T));


            //loop through each object parse to csv
            foreach (var t in objects)
            {
                SerializeLine<T>(t);
            }

            return _stringBuilder.ToString();
        }

        private void AddAllHeaders(Type type)
        {
            var csvFileHeaderConverter = _csvFileHeaderFactory.GetFileHeaderConverter(type);

            var properties = type.GetProperties();
            bool AddCommaFunc(int index) => index < properties.Length;

            var i = 1;
            foreach (var property in properties)
            {
                _stringBuilder.Append(csvFileHeaderConverter.GetHeader(property.Name));
                if (AddCommaFunc(i))
                {
                    _stringBuilder.Append(Comma);
                }

                i++;
            }

            _stringBuilder.Append(Environment.NewLine);
        }

        private void SerializeLine<T>(T t)
        {
            var typeOfT = t.GetType();
            var tProeprties = typeOfT.GetProperties();

            bool AddCommaFunc(int index) => index < tProeprties.Length;


            var i = 1;
            foreach (var proeprty in tProeprties)
            {
                try
                {
                    var propertyValue = proeprty.GetValue(t)?.ToString();

                    _stringBuilder.Append(propertyValue);

                    if (AddCommaFunc(i))
                        _stringBuilder.Append(Comma);

                    i++;
                }
                catch (Exception e)
                {
                    var message = $"Error in Serialize Line. The property was {proeprty.Name}.";
                    if (tProeprties.Any(x => x.Name == "Id"))
                    {
                        var idProperty = typeOfT.GetProperty("Id");
                        var id = idProperty?.GetValue(t);
                        message += $" The Id of the object is {id}";
                    }

                    AddressLogger.LogError(message,e);
                    Console.WriteLine(e);
                    throw;
                }
            }

            _stringBuilder.Append(Environment.NewLine);
        }

        private T DeserializeLine<T>(string line, IEnumerable<PropertyIndex> propertyNames) where T : class, new()
        {
            var t = new T();
            var typeOfT = t.GetType();
            var lineArray = line.Split(Comma.ToCharArray());

            var csvPropertySetter = new NullableCsvPropertySetter();

            foreach (var propertyIndex in propertyNames)
            {
                if(propertyIndex.Name.ToLower() == "Id".ToLower()) continue;
                var property = typeOfT.GetProperties().FirstOrDefault(x=>x.Name.ToLower() == propertyIndex.Name.ToLower());
                var value = lineArray[propertyIndex.Index];

                if (property == null) 
                    throw new NullReferenceException($"A column in the csv is invalid, please check {propertyIndex.Name}");

                if (!string.IsNullOrWhiteSpace(value))
                {
                    csvPropertySetter.SetValue(ref t,value,property.PropertyType, property);
                }
            }

            return t;
        }

        private List<string> SplitIntoLines(string csv)
        {
            return csv.Split(new[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries).ToList();
        }

        private List<PropertyIndex> GetPropertyNames(string csvLine)
        {
            var properties = new List<PropertyIndex>();

            var propertyNames = csvLine.Split(Comma.ToCharArray());

            for (int i = 0; i < propertyNames.Length; i++)
            {
                properties.Add(new PropertyIndex(i,propertyNames[i]));
            }

            return properties;
        }
    }


    internal class PropertyIndex
    {
        public PropertyIndex(int index, string name)
        {
            Index = index;
            Name = name;
        }

        public int Index { get; }

        public string Name { get; }
    }
}