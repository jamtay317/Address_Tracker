﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Address_Tracker.Services.FileServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Address_Tracker.Services.FileServices.FileHeaders;
using Moq;

namespace Address_Tracker.Services.FileServices.Tests
{
    [TestClass()]
    public class CsvServiceTests
    {
        private CsvService _csvService;
        private string csv;
        private Mock<ICsvFileHeaderFactory> _csvHeaderFactoryMock;

        [TestInitialize]
        public void Init()
        {
            _csvHeaderFactoryMock = new Mock<ICsvFileHeaderFactory>();
            _csvService = new CsvService(_csvHeaderFactoryMock.Object);

            csv = BuildCsv();
        }

        [TestMethod]
        public void Parse_stringAsCsv_ShouldParseValue()
        {
            //Act
            var values = _csvService.Deserialize<CsvTestClass>(csv);

            //Assert
            Assert.AreEqual(2, values.Count());

        }

        private string BuildCsv()
        {
            var stringBuilder = new StringBuilder();

            stringBuilder.Append("Id,Name,Cost" + Environment.NewLine);
            stringBuilder.Append("1,Jane,100" + Environment.NewLine);
            stringBuilder.Append("2,Jon, .05" + Environment.NewLine);

            return stringBuilder.ToString();
        }

        [TestMethod]
        public void Parse_AddNullValues_ShouldAddNullValueToObject()
        {
            //Arrange
            var stringBuilder = new StringBuilder(csv);
            stringBuilder.Append(Environment.NewLine);
            stringBuilder.Append("3,dd,");
            csv = stringBuilder.ToString();

            //Act
            var values = _csvService.Deserialize<CsvTestClass>(csv);

            //Assert
            Assert.AreEqual(3,values.Count());
        }
    }

    internal class CsvTestClass
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public decimal Cost { get; set; }
    }
}