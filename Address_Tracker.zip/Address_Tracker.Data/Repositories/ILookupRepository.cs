﻿using System.Linq;
using Address_Tracker.Models.Interfaces;

namespace Address_Tracker.Data.Repositories
{
    public interface ILookupRepository<T> where T : class, IEntity, new()
    {
        T Get(int id);

        IQueryable<T> Get();

    }
}