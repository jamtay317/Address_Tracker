﻿using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using Address_Tracker.Models.Interfaces;

namespace Address_Tracker.Data.Repositories
{
    public interface IRepository<T> : ILookupRepository<T> where T : class, IEntity, new()
    {
        Database Database { get; }

        T Post(T entity);

        T Patch(T entity);

        void Delete(int id);

        void AddRange(IEnumerable<T> entities);
    }
}