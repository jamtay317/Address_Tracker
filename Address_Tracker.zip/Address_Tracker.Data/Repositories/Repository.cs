﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using Address_Tracker.Data.Context.Interfaces;
using Address_Tracker.Models.Interfaces;

namespace Address_Tracker.Data.Repositories
{
    public class Repository<T> : IRepository<T> where T : class, IEntity, new()
    {
        private readonly IAddressContext _context;
        public Database Database => _context.Database;

        public Repository(IAddressContext context)
        {
            _context = context;
        }

        public T Get(int id)
        {
            return _context.Set<T>().FirstOrDefault(x => x.Id == id);
        }

        public IQueryable<T> Get()
        {
            return _context.Set<T>();
        }


        public T Post(T entity)
        {
            _context.Set<T>().Add(entity);
            _context.SaveChanges();
            return entity;
        }

        public T Patch(T entity)
        {
            var databaseEntity = Get(entity.Id);
            if (databaseEntity == null)
                throw new NullReferenceException("Database doesnt contain this entity");

            _context.SetValues(databaseEntity, entity);
            _context.SaveChanges();
            return entity;
        }

        public void Delete(int id)
        {
            var databaseEntity = Get(id);
            if (databaseEntity == null)
                throw new NullReferenceException("Database doesnt contain this entity");

            _context.Set<T>().Remove(databaseEntity);
            _context.SaveChanges();

        }

        public void AddRange(IEnumerable<T> entities)
        {
            _context.Set<T>().AddRange(entities);
            _context.SaveChanges();
        }
    }
}