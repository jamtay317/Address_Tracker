﻿
DECLARE @version INT = 1
DECLARE @patch INT = 14
DECLARE @description NVARCHAR(100) = 'Insert static data into ZipCode'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE Version = @version AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@version,@patch,@description)

		INSERT INTO ZipCode VALUES
		('31092'),
		('31091'),
		('31070'),
		('31007	'),
		('31015'),
		('31063'),
		('31072'),
		('13051')
	
		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		ROLLBACK TRANSACTION
	END CATCH
	
	COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
        