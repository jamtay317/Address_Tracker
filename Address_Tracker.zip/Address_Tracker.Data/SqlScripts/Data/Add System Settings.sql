﻿
DELETE SystemSetting

INSERT INTO SystemSetting VALUES
('SenderEmailAddress','James@jaila-files.com'),
('SenderEmailPassword','BreAnn8Tays1'),
('ReciverEmailAddress','James@jaila-files.com'),
('SmtpHost','smtp.office365.com'),
('SmtpPort','25'),
('SessionTimeOutInDays','30')