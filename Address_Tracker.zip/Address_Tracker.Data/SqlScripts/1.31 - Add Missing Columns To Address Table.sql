﻿
DECLARE @version INT = 1
DECLARE @patch INT = 31
DECLARE @description NVARCHAR(100) = 'Add Missing Columns To Address Table'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE Version = @version AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@version,@patch,@description)

		ALTER TABLE dbo.Address
		ADD AddressStreetName NVARCHAR(100) NULL

		ALTER TABLE dbo.Address
		ADD PictureLink NVARCHAR(500) NULL
		
		-- TODO: Add SQL HERE
		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION
	END CATCH
	IF @@TRANCOUNT > 0
		COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
        