﻿
DECLARE @version INT = 1
DECLARE @patch INT = 39
DECLARE @description NVARCHAR(100) = 'Add Message Table'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE Version = @version AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@version,@patch,@description)

		CREATE TABLE NotificationMessage
		(
			Id INT NOT NULL PRIMARY KEY IDENTITY(1,1),
			SenderName NVARCHAR(100) NOT NULL,
			Message NVARCHAR(MAX) NOT NULL,
			PhoneNumber NVARCHAR(25) NOT NULL,
			EmailAddress NVARCHAR(150) NOT NULL,
			Subject NVARCHAR(125) NOT NULL,
			IsRead BIT NOT NULL CONSTRAINT DF_IsRead DEFAULT 0,
			DateSent DATETIME2 NOT NULL
		)

		-- TODO: Add SQL HERE
		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		ROLLBACK TRANSACTION
	END CATCH
	COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
        