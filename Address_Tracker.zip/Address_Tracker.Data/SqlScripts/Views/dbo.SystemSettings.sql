﻿IF EXISTS(SELECT 1 FROM sys.views WHERE name = 'SystemSettings' AND type = 'v')
	DROP VIEW dbo.SystemSettings
GO

CREATE VIEW dbo.SystemSettings
AS
WITH CTE
AS
(
	SELECT
		--Must Add Setting Here
		CAST(ROW_NUMBER() OVER (order by ReciverEmailAddress) AS INT) AS Id,
		[ReciverEmailAddress],
		[SenderEmailAddress],
		[SenderEmailPassword],
		[SmtpHost],
		CAST([SmtpPort] AS INT) AS SmtpPort,
		CAST([SessionTimeOutInDays] AS INT) AS SessionTimeOutInDays
	FROM SystemSetting as src 
	PIVOT (
		MAX(src.Value)
		FOR src.NAME IN (
			[ReciverEmailAddress],
			[SenderEmailAddress],
			[SenderEmailPassword],
			[SmtpHost],
			[SmtpPort],
			[SessionTimeOutInDays]
			-- Must ADD Setting here
		)
	)AS PVT
)
SELECT * from CTE