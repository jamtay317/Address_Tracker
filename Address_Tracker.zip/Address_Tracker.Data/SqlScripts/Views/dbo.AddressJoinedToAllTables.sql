﻿IF EXISTS(SELECT 1 FROM sys.views WHERE name = 'AddressJoinedToAllTables' AND type = 'v')
	DROP VIEW dbo.AddressJoinedToAllTables
GO

CREATE VIEW dbo.AddressJoinedToAllTables
AS
	SELECT
		  Address.Id
		, Address.HouseNumber
		, Address. NameOfBusiness
		, Community.Name AS CommunityName
		, Address.County
		, Address.EsnNumber
		, Address.SubDivision
		, Address.PropertyDescription
		, PrefixCardinalDirection.Name AS PrefixCardinalDirection
		, SuffixDirection.Name as SuffixDirection
		, Address.StreetNumber
		, Address.RoadType
		, Address.FirstPartOfStreetName
		, Address.StreetName
		, Address.Longitude
		, Address.Latitude
		, PowerCompany.Name AS PowerCompany
		, Address.TotalAddress
		, ZipCode.Name AS ZipCode
		, Address.Notes
		, PointType.Name AS PointType
		, Address.LastName
		, Address.FirstName
		, Address.MiddleName
		, Address.OldLatitude
		, Address.OldLongitude
		, Zoning.Name AS Zoning
		, Address.FloodPlane
		, Address.District
		, Address.ParcelNumber
		, Address.RealKey
		, Address.QPublicLink
		, Address.GoogleMapsLink
		, Address.DirectionsLink
		, Address.AccessoryKey
		, Address.MobileHomeKey
		, Municipality.Name AS  Municipality
		, Address.AddressStreetName
		, Address.PictureLink
		, Address.AppartmentNumber

	FROM dbo.Address
	LEFT OUTER JOIN dbo.Community ON Address.CommunityId = Community.Id
	LEFT OUTER JOIN dbo.Direction AS PrefixCardinalDirection  ON Address.PrefixCardinalDirectionId = PrefixCardinalDirection.Id
	LEFT OUTER JOIN dbo.Direction AS SuffixDirection  ON Address.PrefixCardinalDirectionId = SuffixDirection.Id
	LEFT OUTER JOIN dbo.PowerCompany ON Address.PowerCompanyId = PowerCompany.Id
	LEFT OUTER JOIN dbo.ZipCode ON Address.ZipCodeId = ZipCode.Id
	LEFT OUTER JOIN dbo.PointType ON Address.PointTypeId = PointType.Id
	LEFT OUTER JOIN dbo.Zoning ON Address.ZoningId = Zoning.Id
	LEFT OUTER JOIN dbo.Municipality ON Address.MuncipalityId = Municipality.Id
