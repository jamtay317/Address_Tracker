﻿
DECLARE @minor INT = 1
DECLARE @patch INT = 8
DECLARE @description NVARCHAR(100) = 'Create Address Table'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE  Version =@minor AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@minor,@patch,@description)

		Create table Address
		(
			Id INT PRIMARY KEY IDENTITY(1,1),
			HouseNumber INT NOT NULL,
			AppartmentNumber INT NULL,
			NameOfBusiness NVARCHAR(50) NULL,
			CommunityId INT NULL CONSTRAINT FK_Address_TO_Community FOREIGN KEY REFERENCES Community(Id),
			County NVARCHAR(50) NOT NULL DEFAULT 'Dooly',
			EsnNumber INT NOT NULL CONSTRAINT CK_EsnNumber CHECK (EsnNumber IN (523,526,522,525,528,521,524,529,527,325)),
			SubDivision NVARCHAR(50) NULL,
			PropertyDescription NVARCHAR(1000) NULL,
			PrefixCardinalDirectionId INT NULL CONSTRAINT FK_AddressPrefix_TO_Direction FOREIGN KEY REFERENCES Direction(Id),
			SuffixDirectionId INT NULL CONSTRAINT FK_AddressSuffix_TO_Direction FOREIGN KEY REFERENCES Direction(Id),
			StreetNumber INT NOT NULL,
			RoadType NVARCHAR(10) NULL,
			StreetName NVARCHAR(50) NULL,
			Longitude DECIMAL(15,12) NULL,
			Latitude DECIMAL(15,12) NULL,
			PowerCompanyId INT NULL CONSTRAINT FK_Address_TO_PowerCompany FOREIGN KEY REFERENCES PowerCompany(Id),
			ZipCode NVARCHAR(5) NOT NULL,
			Notes NVARCHAR(1000) NULL,
			PointTypeId INT NULL CONSTRAINT FK_Address_TO_PointType FOREIGN KEY REFERENCES PointType(Id),
			LastName NVARCHAR(50) NULL,
			FirstName NVARCHAR(50) NULL,
			MiddleName NVARCHAR(50) NULL,
			OldLongitude DECIMAL(15,12) NULL,
			OldLatitude DECIMAL(15,12) NULL,
			ZoningId INT NULL CONSTRAINT FK_AddressPrefix_TO_Zoning FOREIGN KEY REFERENCES Zoning(Id),
			FloodPlane BIT NOT NULL,
			District INT NOT NULL CONSTRAINT CK_District Check (District IN (1,2,3,4,5)),
			ParcelNumber NVARCHAR(30) NULL,
			RealKey INT NOT NULL,
			QPublicLink NVARCHAR(500) NULL,
			GoogleMapsLink Nvarchar(500) NULL,
			DirectionsLink Nvarchar(500) NULL,
			AccessoryKey INT NULL,
			MobileHomeKey INT NULL
		)

		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		
		ROLLBACK TRANSACTION
	END CATCH
	
	COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
