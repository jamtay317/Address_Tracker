﻿INSERT INTO SystemDb(Version,Patch,Description) VALUES('1','45','Add District Values')

INSERT INTO [dbo].[District](Name) VALUES ('1'),('2'),('3'),('4'),('5')