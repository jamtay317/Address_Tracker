﻿
DELETE dbo.SystemDb WHERE Version = 1 AND Patch = 46
INSERT INTO dbo.SystemDb(Version,Patch,Description) VALUES (1,46,'EDIT Address table for required fields')

ALTER TABLE Address
Alter column RealKey INT NULL

ALTER TABLE Address
Alter column TotalAddress NVARCHAR(50) NOT NULL

ALTER TABLE Address
Alter column CommunityId INT NOT NULL

ALTER TABLE Address
Alter column MuncipalityId INT NOT NULL

ALTER TABLE Address
Alter column Longitude DECIMAL(18,15) NOT NULL

ALTER TABLE Address
Alter column Latitude DECIMAL(18,15) NOT NULL

ALTER TABLE Address
Alter column ZipCodeId INT NOT NULL

ALTER TABLE Address
Alter column PointTypeId INT NOT NULL

ALTER TABLE Address
Alter column HouseNumber INT NOT NULL

ALTER TABLE Address
Alter column County NVARCHAR(50) NOT NULL

ALTER TABLE Address
Alter column StreetNumber INT NOT NULL

ALTER TABLE Address
Alter column StreetName NVARCHAR(50) NOT NULL

ALTER TABLE Address
Alter column District INT NULL