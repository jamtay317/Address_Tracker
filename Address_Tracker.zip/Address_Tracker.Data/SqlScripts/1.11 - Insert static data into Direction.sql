﻿
DECLARE @version INT = 1
DECLARE @patch INT = 11
DECLARE @description NVARCHAR(100) = 'Insert static data into direction'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE  Version =@version AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@version,@patch,@description)

		INSERT INTO Direction VALUES
		('N'),
		('S'),
		('E'),
		('W')

		-- TODO: Add SQL HERE
		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		ROLLBACK TRANSACTION
	END CATCH
	COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
        