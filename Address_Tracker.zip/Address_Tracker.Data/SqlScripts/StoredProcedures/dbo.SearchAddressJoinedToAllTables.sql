﻿IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'SearchAddressJoinedToAllTables') AND TYPE IN (N'P',N'PC'))
	DROP PROCEDURE dbo.SearchAddressJoinedToAllTables
GO


CREATE PROCEDURE dbo.SearchAddressJoinedToAllTables
	@PageSize INT = 50,
	@Start INT =1,
	@StreetName NVARCHAR(100)='',
	@Esn INT = NULL,
	@Notes NVARCHAR(500)='',
	@ParcelNumber NVARCHAR(50)='',
	@ZoningCode NVARCHAR(50)='',
	@HouseNumber NVARCHAR(25)='',
	@County NVARCHAR(100)='',
	@Municipality NVARCHAR(50)='',
	@UniqueId INT= NULL,
	@District INT= NULL,
	@SubDivision NVARCHAR(100)=''
AS
BEGIN
	if(@PageSize = 0)
		SET @PageSize = 100000
	if(@Start = 0)
		SET @Start = 0

	;WITH CTE
	AS
	(
		SELECT 
			  Id
			, HouseNumber
			, NameOfBusiness
			, CommunityName AS Community
			, County
			, SubDivision
			, PropertyDescription
			, PrefixCardinalDirection
			, SuffixDirection
			, StreetNumber
			, RoadType
			, FirstPartOfStreetName
			, StreetName
			, EsnNumber
			, Longitude
			, Latitude
			, PowerCompany
			, TotalAddress
			, ZipCode
			, Notes
			, LastName
			, FirstName
			, MiddleName
			, OldLatitude
			, OldLongitude
			, Zoning
			, FloodPlane
			, District
			, ParcelNumber
			, RealKey
			, QPublicLink
			, GoogleMapsLink
			, DirectionsLink
			, AccessoryKey
			, MobileHomeKey
			, Municipality
			, AddressStreetName
			, PictureLink
			, PointType
			, AppartmentNumber
			, ROW_NUMBER() OVER (ORDER BY OBJECT_NAME(Id)) AS RowNumber
		FROM dbo.AddressJoinedToAllTables
		WHERE (StreetName LIKE '%' + @StreetName + '%' OR @StreetName = '')
		  AND (Notes LIKE '%' + @Notes + '%' OR @Notes = '')
		  AND (ParcelNumber LIKE '%' + @ParcelNumber + '%' OR @ParcelNumber ='')
		  AND (Zoning LIKE '%' + @ZoningCode + '%' OR @ZoningCode = '')
		  AND (HouseNumber LIKE '%' + @HouseNumber + '%' OR @HouseNumber ='')
		  AND (County LIKE '%' + @County + '%' OR @County = '')
		  AND (Municipality LIKE '%' + @Municipality + '%' OR @Municipality ='')
		  AND (SubDivision LIKE '%' + @SubDivision +'%' OR @SubDivision = '')
		  AND (CAST(EsnNumber AS NVARCHAR) LIKE '%'+ CAST(@Esn AS nvarchar) + '%' OR @Esn IS NULL)
		  AND (CAST(District AS NVARCHAR) LIKE '%'+ CAST(@District AS nvarchar) + '%' OR @Esn IS NULL)
		  AND (Id = @UniqueId OR @UniqueId IS NULL)
	)
	SELECT 
		  Id
			, HouseNumber
			, NameOfBusiness
			, Community
			, County
			, SubDivision
			, PropertyDescription
			, PrefixCardinalDirection
			, SuffixDirection
			, StreetNumber
			, RoadType
			, FirstPartOfStreetName
			, StreetName
			, EsnNumber
			, Longitude
			, Latitude
			, PowerCompany
			, TotalAddress
			, ZipCode
			, Notes
			, LastName
			, FirstName
			, MiddleName
			, OldLatitude
			, OldLongitude
			, Zoning
			, FloodPlane
			, District
			, ParcelNumber
			, RealKey
			, QPublicLink
			, GoogleMapsLink
			, DirectionsLink
			, AccessoryKey
			, MobileHomeKey
			, Municipality as Muncipality
			, AddressStreetName
			, PictureLink
			, PointType
			, AppartmentNumber
	FROM CTE
WHERE RowNumber BETWEEN @Start AND (@Start + @PageSize-1)
END