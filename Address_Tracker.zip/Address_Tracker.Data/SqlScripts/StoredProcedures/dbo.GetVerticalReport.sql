﻿IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'GetVerticallReport') AND TYPE IN (N'P',N'PC'))
	DROP PROCEDURE dbo.GetVerticallReport
GO

CREATE PROCEDURE dbo.GetVerticallReport
AS
BEGIN
	SELECT 
		AddressJoinedToAllTables.HouseNumber,
		AddressJoinedToAllTables.SuffixDirection,
		AddressJoinedToAllTables.StreetName,
		AddressJoinedToAllTables.EsnNumber,
		AddressJoinedToAllTables.PropertyDescription,
		AddressJoinedToAllTables.FirstName,
		AddressJoinedToAllTables.LastName,
		AddressJoinedToAllTables.CommunityName
	FROM dbo.AddressJoinedToAllTables
END