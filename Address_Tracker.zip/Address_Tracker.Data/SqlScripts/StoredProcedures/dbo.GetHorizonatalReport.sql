﻿IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'GetHorizonatalReport') AND TYPE IN (N'P',N'PC'))
	DROP PROCEDURE dbo.GetHorizonatalReport
GO

CREATE PROCEDURE dbo.GetHorizonatalReport
AS
BEGIN
	SELECT 
		AddressJoinedToAllTables.HouseNumber,
		AddressJoinedToAllTables.SuffixDirection,
		AddressJoinedToAllTables.StreetName,
		AddressJoinedToAllTables.EsnNumber,
		AddressJoinedToAllTables.ZipCode,
		AddressJoinedToAllTables.PropertyDescription,
		AddressJoinedToAllTables.FirstName,
		AddressJoinedToAllTables.LastName,
		AddressJoinedToAllTables.MiddleName,
		AddressJoinedToAllTables.CommunityName,
		AddressJoinedToAllTables.ParcelNumber
	FROM dbo.AddressJoinedToAllTables
END