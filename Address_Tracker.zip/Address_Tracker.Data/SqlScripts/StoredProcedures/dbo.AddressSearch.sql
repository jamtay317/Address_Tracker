﻿IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'AddressSearch') AND TYPE IN (N'P',N'PC'))
	DROP PROCEDURE dbo.AddressSearch
GO

CREATE PROCEDURE dbo.AddressSearch
	@PageSize INT = 50,
	@Start INT =1,
	@StreetName NVARCHAR(100)='',
	@Esn INT = NULL,
	@Notes NVARCHAR(500)='',
	@ParcelNumber NVARCHAR(50)='',
	@ZoningCode NVARCHAR(50)='',
	@HouseNumber NVARCHAR(25)='',
	@County NVARCHAR(100)='',
	@Municipality NVARCHAR(50)='',
	@UniqueId INT= NULL,
	@District INT= NULL,
	@SubDivision NVARCHAR(100)='',
	@Community NVARCHAR(50)='',
	@PointType NVARCHAR(50)=''
AS
BEGIN

	IF (@PageSize = 0)
		SET @PageSize = 100000

	;WITH CTE
	AS
	(
		SELECT 
			  Id
			, HouseNumber
			, StreetName
			, AppartmentNumber
			, EsnNumber
			, PropertyDescription AS Description
			, TotalAddress
			, PointType
			, CommunityName AS Community
			, Zoning AS ZoningCode
			, District
			, Notes
			, ROW_NUMBER() OVER (ORDER BY OBJECT_NAME(Id)) AS RowNumber
		FROM dbo.AddressJoinedToAllTables 
		WHERE (AddressStreetName LIKE '%' + @StreetName + '%' OR @StreetName = '')
		  AND (Notes LIKE '%' + @Notes + '%' OR @Notes = '')
		  AND (ParcelNumber LIKE '%' + @ParcelNumber + '%' OR @ParcelNumber ='')
		  AND (Zoning LIKE '%' + @ZoningCode + '%' OR @ZoningCode = '')
		  AND (HouseNumber LIKE '%' + @HouseNumber + '%' OR @HouseNumber ='')
		  AND (County LIKE '%' + @County + '%' OR @County = '')
		  AND (Municipality LIKE '%' + @Municipality + '%' OR @Municipality ='')
		  AND (SubDivision LIKE '%' + @SubDivision +'%' OR @SubDivision = '')
		  AND (PointType LIKE '%' + @PointType +'%' OR @PointType = '')
		  AND (CommunityName LIKE '%'+ @Community + '%' OR @Community = '')
		  AND (CAST(EsnNumber AS NVARCHAR) LIKE '%'+ CAST(@Esn AS nvarchar) + '%' OR @Esn IS NULL)
		  AND (District = @District OR @District IS NULL)
		  AND (Id = @UniqueId  OR @UniqueId IS NULL)
	)
	SELECT 
		  Id
		, HouseNumber
		, StreetName
		, AppartmentNumber
		, EsnNumber
		, Description
		, TotalAddress
		, PointType
		, Community
		, ZoningCode
		, District
		, Notes
	FROM CTE
WHERE RowNumber BETWEEN @Start AND (@Start + @PageSize-1)
ORDER BY HouseNumber, AppartmentNumber, TotalAddress
END