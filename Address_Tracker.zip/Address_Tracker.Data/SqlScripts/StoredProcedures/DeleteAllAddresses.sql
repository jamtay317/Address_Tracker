﻿IF EXISTS(SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID('dbo.DeleteAllAddresses') AND type in (N'P', N'PC'))
	DROP PROCEDURE dbo.DeleteAllAddresses
GO

CREATE PROCEDURE dbo.DeleteAllAddresses
AS
BEGIN
	DELETE Address
END