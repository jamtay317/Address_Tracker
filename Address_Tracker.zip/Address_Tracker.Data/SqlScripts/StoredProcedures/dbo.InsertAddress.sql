﻿IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'InsertAddress') AND TYPE IN (N'P',N'PC'))
	DROP PROCEDURE dbo.InsertAddress
GO


CREATE PROCEDURE InsertAddress
	@HouseNumber int = NULL,
	@AppartmentNumber nvarchar(50) = NULL,
	@NameOfBusiness nvarchar(50) = NULL,
	@CommunityId int  = NULL,
	@County nvarchar(50) = NULL,
	@EsnNumber int = NULL,
	@SubDivision nvarchar(50) = NULL,
	@PropertyDescription nvarchar(1000) = NULL,
	@PrefixCardinalDirectionId int = NULL,
	@SuffixDirectionId int = NULL,
	@StreetNumber int = NULL,
	@RoadType nvarchar(10) = NULL,
	@StreetName nvarchar(50) = NULL,
	@Longitude decimal(18, 15) = NULL,
	@Latitude decimal(18, 15) = NULL,
	@PowerCompanyId int = NULL,
	@ZipCodeId int = NULL,
	@Notes nvarchar(1000) = NULL,
	@PointTypeId int = NULL,
	@LastName nvarchar(50) = NULL,
	@FirstName nvarchar(50) = NULL,
	@MiddleName nvarchar(50) = NULL,
	@OldLongitude decimal(18, 15) = NULL,
	@OldLatitude decimal(18, 15) = NULL,
	@ZoningId int = NULL,
	@FloodPlane bit = NULL ,
	@District int = NULL ,
	@ParcelNumber nvarchar(30) = NULL,
	@RealKey int = NULL,
	@QPublicLink nvarchar(500) = NULL,
	@GoogleMapsLink nvarchar(500) = NULL,
	@DirectionsLink nvarchar(500) = NULL,
	@AccessoryKey int = NULL,
	@MobileHomeKey int = NULL,
	@MuncipalityId int = NULL,
	@TotalAddress nvarchar(125) = NULL,
	@FirstPartOfStreetName nvarchar(100) = NULL,
	@AddressStreetName nvarchar(100) = NULL,
	@PictureLink nvarchar(500) = NULL

AS
BEGIN

INSERT INTO [dbo].[Address]
           ([HouseNumber]
           ,[AppartmentNumber]
           ,[NameOfBusiness]
           ,[CommunityId]
           ,[County]
           ,[EsnNumber]
           ,[SubDivision]
           ,[PropertyDescription]
           ,[PrefixCardinalDirectionId]
           ,[SuffixDirectionId]
           ,[StreetNumber]
           ,[RoadType]
           ,[StreetName]
           ,[Longitude]
           ,[Latitude]
           ,[PowerCompanyId]
           ,[ZipCodeId]
           ,[Notes]
           ,[PointTypeId]
           ,[LastName]
           ,[FirstName]
           ,[MiddleName]
           ,[OldLongitude]
           ,[OldLatitude]
           ,[ZoningId]
           ,[FloodPlane]
           ,[District]
           ,[ParcelNumber]
           ,[RealKey]
           ,[QPublicLink]
           ,[GoogleMapsLink]
           ,[DirectionsLink]
           ,[AccessoryKey]
           ,[MobileHomeKey]
           ,[MuncipalityId]
           ,[TotalAddress]
           ,[FirstPartOfStreetName]
           ,[AddressStreetName]
           ,[PictureLink])
     VALUES
           (@HouseNumber
           ,@AppartmentNumber
           ,@NameOfBusiness
           ,@CommunityId
           ,@County
           ,@EsnNumber
           ,@SubDivision
           ,@PropertyDescription
           ,@PrefixCardinalDirectionId
           ,@SuffixDirectionId
           ,@StreetNumber
           ,@RoadType
           ,@StreetName
           ,@Longitude
           ,@Latitude
           ,@PowerCompanyId
           ,@ZipCodeId
           ,@Notes
           ,@PointTypeId
           ,@LastName
           ,@FirstName
           ,@MiddleName
           ,@OldLongitude
           ,@OldLatitude
           ,@ZoningId
           ,@FloodPlane
           ,@District
           ,@ParcelNumber
           ,@RealKey
           ,@QPublicLink
           ,@GoogleMapsLink
           ,@DirectionsLink
           ,@AccessoryKey
           ,@MobileHomeKey
           ,@MuncipalityId
           ,@TotalAddress
           ,@FirstPartOfStreetName
           ,@AddressStreetName
           ,@PictureLink)

END
GO



