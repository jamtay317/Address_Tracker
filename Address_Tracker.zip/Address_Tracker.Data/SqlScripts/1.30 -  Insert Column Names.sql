﻿
DECLARE @version INT = 1
DECLARE @patch INT = 30
DECLARE @description NVARCHAR(100) = 'Insert Column Names'

IF NOT EXISTS(SELECT 1 FROM SystemDB WHERE Version =@version AND Patch = @patch)
BEGIN
	BEGIN TRANSACTION			
	BEGIN TRY
		INSERT INTO SystemDB VALUES (@version,@patch,@description)

		INSERT INTO DatabaseColumnName(ExportName,CurrentName,ListOrder,[Description])  VALUES
		('Id','Id', 1, 'Unique ID'),
		('NUMBER_','HouseNumber', 2, 'House Number'),
		('APARTMENT','AppartmentNumber', 3, 'Apartment Number (if applicable)'),

		('ADDRESS','AddressStreetName', 4, 'Street Name'),

		('MAIN_CPN','NameOfBusiness', 5, 'Name of Business (if applicable)'),
		('COMMUNITY','Community', 6, 'City structure is located in'),
		('COUNTY','County', 7, 'Will always be Dooly'),
		('ESN','EsnNumber', 8, 'ESN Number'),
		('SUBDIV','SubDivision', 9, 'If the subdivisin that the stucture is in has a name it goes here'),
		('DESCRIP','PropertyDescription', 10, 'Written Description of the property'),
		('PRE_DIR','PrefixCardinalDirection', 11, 'Prefix Cardinal Direction'),

		('PRE_TYPE','FirstPartOfStreetName', 12, 'First part of HWY name as in HWY 230'),

		('STREET_NAM','StreetName', 13, 'First part of Street Name'),
		('STREET_TYP','RoadType', 14, 'ST, EXT, AVE, LN, Ect'),
		('SUF_DIR','SuffixDirection', 15, 'Suffix Cardinal Direction'),
		('STNAM','StreetNumber', 16, 'Same as NUMBER_'),
		('X','Longitude', 17, 'Longitude'),
		('Y','Latitude', 18, 'Latitude'),
		('POWER','PowerCompany', 19, 'Who provices power to this structure'),
		('ADD_COMB','TotalAddress', 20, 'Total Address'),
		('ZIP','ZipCode', 21,'Zipcode of structure'),
		('MUNICIPALITY','Muncipality', 22, 'Should be same as Community'),
		('NOTES','Notes', 23, 'Notes on the structure'),
		('POINT_TYPE','PointType', 24, 'What type of point is this, Res, Comm, Int, Begin, End, Fire Hydrant, ect'),
		('LASTNAME','LastName', 25, 'Last Name of Structure resident'),
		('FIRSTNAME','FirstName', 26, 'First Name of Structure resident'),
		('MIDDLENAME','MiddleName', 27, 'Middle Name of Structure resident'),
		('OLD_LAT','OldLatitude', 28, 'Latitude from old program'),
		('OLD_LON','OldLongitude', 29, 'Longitude from old program'),
		('ZONING','Zoning', 30, 'Zoning code for this strucure'),
		('FLOOD_PLANE','FloodPlane', 31, 'Is this stucture in a flood plane (yes no)'),
		('DISTRICT','District', 32, 'What election district is this structure in'),
		('PARCEL_NO','ParcelNumber', 33, 'What parcel does this strucutre sit on'),
		('REALKEY','RealKey', 34, 'What is the realkey for this structure'),
		('QPUB_lINK','QPublicLink', 35, 'Link to the parcel this structure sits on in q public'),
		('GMAPS_LINK','GoogleMapsLink', 36, 'Link to this gps on google maps'),
		('DIRECTIONS_LINK','DirectionsLink', 37, 'Google maps link giving directions from current location'),

		('PIC_LINK','PictureLink', 38, 'Link to picture of structure'),

		('ACC_KEY','AccessoryKey', 39, 'Accessory Key'),
		('MOB_KEY','MobileHomeKey', 40, 'Mobile Home Key')

		-- TODO: Add SQL HERE
		PRINT @description + 'Was completed'
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE() AS ErrorMessage, ERROR_LINE() AS ErrorLine, ERROR_NUMBER() AS ErrorNumber
		
		ROLLBACK TRANSACTION
	END CATCH
	
	COMMIT TRANSACTION
END
ELSE
BEGIN
	PRINT 'That record is already in db'
END
GO
        