﻿
USE [master]

IF EXISTS(select * from sys.databases where name='AddressTracker')
	DROP DATABASE AddressTracker
GO


CREATE DATABASE AddressTracker
GO

USE AddressTracker

CREATE TABLE SystemDb
(
	Version INT NOT NULL,
	Patch INT NOT NULL,
	Description NVARCHAR(100) NOT NULL
)
GO

INSERT INTO SystemDb VALUES(1,1,'Create Database and SystemDb Table')
