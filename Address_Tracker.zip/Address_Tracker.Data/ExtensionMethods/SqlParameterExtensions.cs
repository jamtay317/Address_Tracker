﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Data.ExtensionMethods
{
    public static class SqlParameterExtensions
    {
        public static SqlParameter AddValue(this SqlParameter parameter, object value)
        {
            parameter.Value = value;
            return parameter;
        }
    }
}
