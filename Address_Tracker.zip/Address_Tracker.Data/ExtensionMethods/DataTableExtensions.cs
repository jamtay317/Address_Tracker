﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Address_Tracker.Data.ExtensionMethods
{
    public static class DataTableExtensions
    {
        public static List<T> ToList<T>(this DataTable dataTable) where T:class, new()
        {
            var list = new List<T>();
            var typeOfT = typeof(T);
            var properties = typeOfT.GetProperties();

            foreach (DataRow dataRow in dataTable.Rows)
            {
                var t = new T();
                foreach (var property in properties)
                {
                    var value = dataRow[property.Name].ToString();
                    if (property.PropertyType.IsGenericType &&
                        property.PropertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
                    {
                        if (!string.IsNullOrWhiteSpace(value))
                        {
                            property.SetValue(t, Convert.ChangeType(value, Nullable.GetUnderlyingType(property.PropertyType)), null);
                        }
                    }
                    else
                    {
                        property.SetValue(t, Convert.ChangeType(value, property.PropertyType), null);
                    }
                }
                list.Add(t);
            }

            return list;
        }
    }
}
