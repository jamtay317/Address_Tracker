﻿using System.Data.Entity;
using Address_Tracker.Data.ConfigurationServices;
using Address_Tracker.Data.Context.Interfaces;
using Address_Tracker.Models;

namespace Address_Tracker.Data.Context
{
    public class AddressContext:DbContext,IAddressContext
    {
        public AddressContext(IConfigurationService configurationService):base($"{configurationService.AppSetting("mode")}ConnectionString")
        {
            
        }

        public DbSet<ActiveSession> ActiveSessions { get; set; }

        public virtual DbSet<Address> Addresses { get; set; }

        public virtual DbSet<Community> Communities { get; set; }

        public virtual DbSet<DatabaseColumnName> DatabaseColumnNames { get; set; }

        public virtual DbSet<Direction> Directions { get; set; }

        public virtual DbSet<District> Districts { get; set; }

        public virtual DbSet<Message> Messages { get; set; }

        public virtual DbSet<Municipality> Municipalities { get; set; }

        public virtual DbSet<PointType> PointTypes { get; set; }

        public virtual DbSet<PowerCompany> PowerCompanies { get; set; }

        public virtual DbSet<Report> Reports { get; set; }

        public virtual DbSet<SystemSetting> SystemSettings { get; set; }

        public virtual DbSet<User> Users { get; set; }

        public virtual DbSet<Zoning> Zonings { get; set; }

        public void SetValues<TEntity>(TEntity databaseEntity, TEntity newValues) where TEntity : class
        {
            Entry(databaseEntity).CurrentValues.SetValues(newValues);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<AddressContext>(null);
            base.OnModelCreating(modelBuilder);
        }
    }

}