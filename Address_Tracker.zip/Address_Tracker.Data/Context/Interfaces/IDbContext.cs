﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;

namespace Address_Tracker.Data.Context.Interfaces
{
    public interface IDbContext
    {
        Database Database { get; }
        DbChangeTracker ChangeTracker { get; }
        DbEntityEntry Entry(object entity);
        DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;
        DbContextConfiguration Configuration { get; }
        IEnumerable<DbEntityValidationResult> GetValidationErrors();
        DbSet Set(Type entityType);
        DbSet<TEntity> Set<TEntity>() where TEntity : class;
        int SaveChanges();
        void SetValues<TEntity>(TEntity databaseEntity, TEntity newValues) where TEntity : class;
    }
}