﻿using System.Data.Entity;
using Address_Tracker.Models;

namespace Address_Tracker.Data.Context.Interfaces
{
    public interface IAddressContext:IDbContext
    {
        DbSet<Address> Addresses { get; set; }

        DbSet<Community> Communities { get; set; }

        DbSet<DatabaseColumnName> DatabaseColumnNames { get; set; }

        DbSet<Direction> Directions { get; set; }

        DbSet<Message> Messages { get; set; }

        DbSet<Municipality> Municipalities { get; set; }

        DbSet<PointType> PointTypes { get; set; }

        DbSet<PowerCompany> PowerCompanies { get; set; }

        DbSet<Report> Reports { get; set; }

        DbSet<SystemSetting> SystemSettings { get; set; }

        DbSet<User> Users { get; set; }

        DbSet<Zoning> Zonings { get; set; }
    }
}