﻿using System.Configuration;

namespace Address_Tracker.Data.ConfigurationServices
{
    public class ConfigurationService:IConfigurationService
    {
        public string AppSetting(string name)
        {
            return ConfigurationManager.AppSettings[name];
        }

        public string ConnectionString(string name)
        {
            return ConfigurationManager.ConnectionStrings[name].ConnectionString;
        }

        public string CurrentConnectionString => ConnectionString($"{AppSetting("mode")}ConnectionString");
    }
}