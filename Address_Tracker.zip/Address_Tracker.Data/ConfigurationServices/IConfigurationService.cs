﻿namespace Address_Tracker.Data.ConfigurationServices
{
    public interface IConfigurationService
    {
        string AppSetting(string name);

        string ConnectionString(string name);

        string CurrentConnectionString { get; }
    }
}