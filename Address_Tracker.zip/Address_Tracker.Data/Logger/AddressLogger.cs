﻿using System;
using System.IO;
using Address_Tracker.Data.ConfigurationServices;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Layout;
using log4net.Repository.Hierarchy;

namespace Address_Tracker.Data.Logger
{
    public class AddressLogger
    {
       
        public static string LogFileName => "AddressLogger.log";
        private static FileAppender GetAppender()
        {
            IConfigurationService configurationService = new ConfigurationService();

            var mode = configurationService.AppSetting("mode");
            var filePath = configurationService.AppSetting($"{mode}LogPath");

            var layout = new SimpleLayout();
            layout.ActivateOptions();

            var appender = new FileAppender();
            appender.File = Path.Combine(filePath, LogFileName);
            appender.Layout = layout;
            appender.ActivateOptions();
            return appender;
        }

        public static void LogMessage(string message)
        {
            ConfigureLogger();
            var log = LogManager.GetLogger("Record Keeping");
            log.Info(message);
        }

        private static void ConfigureLogger()
        {
            var appender = GetAppender();


            var hierarchy = (Hierarchy)LogManager.GetRepository();
            var root = hierarchy.Root;

            root.Level = log4net.Core.Level.All;
            BasicConfigurator.Configure(appender);
        }

        public static void LogError(string error, Exception e)
        {
            ConfigureLogger();
            var log = LogManager.GetLogger("Record Keeping");
            log.Error(error, e);
        }
    }
}