﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.ExceptionHandling;
using Address_Tracker.Data.Logger;

namespace Address_Tracker.ExceptionHandling
{
    public class Log4NewExceptionLogger:ExceptionLogger
    {
        public override void Log(ExceptionLoggerContext context)
        {
            AddressLogger.LogMessage(context.RequestContext.Principal.Identity.Name);
            AddressLogger.LogError("Date: " + DateTime.Now.ToString(), context.Exception);
        }
    }
}