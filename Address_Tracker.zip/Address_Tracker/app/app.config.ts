﻿import { Injectable, OnInit } from '@angular/core';

import { SessionService } from './session.service';

import * as moment from 'moment';

@Injectable()
export class AppConfig  {

    constructor(private sessionService:SessionService) {
        this.app = (<any>window).App;
        this.username = this.app.username;
        this.role = this.app.role;
        this.daysUntillTimeout = this.app.daysUntillTimeout;
        this.lastLogin = this.app.lastLogin;
        this.session = {
            username: this.app.session.username,
            sessionExpires: this.app.session.sessionExpires,
            role:this.app.role
        };
        this.setSessionInfo();
    }

    app:any;

    username: string = '';

    role: string = '';

    session: {username:string,sessionExpires:any,role:string};

    daysUntillTimeout: number;
    lastLogin:Date;

    setSessionInfo(): void {
        if (this.username !== undefined &&
            this.username !== '' &&
            this.session.sessionExpires !== undefined &&
            this.session.role !== undefined) {

            var jsonString = JSON.stringify(this.session);
            var expiredDate = moment(this.session.sessionExpires).format('ddd, DD MMM YYYY');
            // document.cookie = `session=${jsonString};expires=${expiredDate};role=${this.session.role}`;
            localStorage.setItem('session', jsonString);
            localStorage.setItem('expires', expiredDate);
            localStorage.setItem('role', this.session.role);

            console.log(this.username);
            console.log(this.session);
        } else {
            this.sessionService.init();
        }
    }
}