﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppConfig } from './app.config';
import { SessionService } from './session.service';

@Component({
    selector: 'app',
    templateUrl: 'app/app.component.html'
})
export class AppComponent implements OnInit {

    constructor(
        public appConfig: AppConfig,
        private sessionService: SessionService,
        private router:Router
    ) { }

    ngOnInit(): void {
        this.sessionService.init();

        if (!this.sessionService.hasSessionInfo()) {
            this.redirectToLogin();
        }
        if (this.appConfig.username === undefined || this.appConfig.username === '') {
            this.appConfig.username = this.sessionService.getUsername();
        }
        if (!this.sessionService.isSessionValid()) {
            this.redirectToLogin();
        }
    }

    onLogout(): void {
        this.sessionService.logout();
        this.sessionService.clearSessionInfo();
        this.redirectToLogin();
    }

    redirectToLogin(): void {
        window.location.href = './Login';
    }
}