﻿(function() {
    window.App = (function() {
        
        return {
            init:function init(viewBag) {

                this.role = viewBag.role;
                this.username = viewBag.username;
                this.daysUntillTimeout = viewBag.daysUntillTimeout;
                this.lastLogin = viewBag.lastLogin;

                this.session = viewBag.session;
            },
        
        };
    }());
}());