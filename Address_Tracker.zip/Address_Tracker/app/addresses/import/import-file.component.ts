﻿import { Component, OnInit } from '@angular/core';

import { AddressService } from '../address.service';

@Component({
    selector: 'import-file',
    templateUrl: 'app/addresses/import/import-file.component.html'
})
export class ImportFileComponent implements OnInit {

    constructor(private addressService:AddressService) {}

    file: any;
    fileName: string;
    fileType: string;
    fileSize:number;

    ngOnInit(): void {
    }

    isFileNameValid(): boolean {
        let isValid = false;
        if (this.fileName) {
            isValid = this.fileName.includes('.csv');
        }
        return isValid;
    }

    isFileSizeValid(): boolean {
        return this.fileSize < 15001;
    }

    onFileChange(files: any): void {
        this.file = files[0];
        this.fileName = this.file.name;
        this.fileType = this.file.type;
        this.fileSize = this.file.size;
    }

    onSubmit(): void {
        let formData = new FormData();
        formData.append("Name", this.fileName);
        formData.append("file", this.file);

        this.addressService.upload(formData).subscribe(result => {
            alert("Upload Sucess");
        },
            error => {
                alert("There was an error, please check the data");
            });
    }
}