﻿export class AddressResultModel {
    id: number;
    houseNumber: string;
    streetName: string;
    esnNumber: string;
    description: string;
    totalAddress: string;
    pointType: string;
    appartmentNumber: string;
    community: string;
    zoningCode: string;
    district: string;
    notes:string;
}