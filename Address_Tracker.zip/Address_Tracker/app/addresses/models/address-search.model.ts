﻿export class AddressSearchModel {
    county: string = '';
    district: number = null;
    esn: number = null;
    houseNumber: number = null;
    municipality: string = '';
    notes: string = '';
    page: number = 0;
    pageSize: number = 50;
    parcelNumber: string = '';
    start:number = 1;
    streetName: string = '';
    subDivision: string = '';
    uniqueId: number = null;
    zoningCode: string = '';
    community: string = '';
    pointType:string='';
    
    setStart(): void {
        this.start = this.page * this.pageSize + 1;
    }
}