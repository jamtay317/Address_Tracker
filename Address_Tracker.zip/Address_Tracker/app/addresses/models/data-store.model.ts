﻿
export class DataStore {
    data: any[] = [];
    selectedAddress: any;
}