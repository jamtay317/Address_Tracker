﻿export enum ModelChangeDirection {
    Next = 1,
    Previous = -1
}