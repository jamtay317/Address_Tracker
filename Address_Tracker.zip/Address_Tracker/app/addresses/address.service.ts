﻿import { Injectable, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from "rxjs/Observable";

import { AddressModel } from './models/address.model';
import { AddressSearchModel } from './models/address-search.model';
import { BaseService } from '../shared/services/service-base.service';
import { DataStore } from './models/data-store.model';
import { ModelChangeDirection } from './models/enums/model-change-direction.enum';


@Injectable()
export class AddressService extends BaseService {

    baseRoute: string = 'api/AddressSearch/';

    addressSearchModel:AddressSearchModel;

    canGoNextAddress: boolean = false;
    canGoPreviousAddress: boolean = false;
    hasSearched: boolean = false;
    hasResults: boolean = false;
    searchComplete: EventEmitter<any> = new EventEmitter<any>();
    updateEntity: EventEmitter<AddressModel> = new EventEmitter<AddressModel>();

    dataStore: DataStore = {
        data: [],
        selectedAddress: null
        
    };

    constructor(protected  http: Http) {
        super(http);
    }

    showSearchResults(): boolean {
        return !this.hasSearched || (this.hasSearched && this.hasResults);
    }
    
    /*
     * this.addressSearchModel is set in address search component and must be for results to turn out correctly 
     */
    getSearchItems(): void {
        if (this.addressSearchModel === undefined)
            throw new Error("searchResultsModel is null and cannot be");

        let url = this.baseRoute + 'Search/';
        this.hasSearched = true;
        this.hasResults = false;
        this.post(url, this.addressSearchModel).subscribe(result => {
            let body = JSON.parse(result._body);
            this.dataStore.data = body;
            this.hasResults = this.dataStore.data.length > 0;
            this.searchComplete.emit();
        }, error => {
            alert('There was an error while processing your request');
            this.searchComplete.emit();
            console.log(error);
        });
    }

    upload(formData:FormData): Observable<any> {
        let url = this.baseRoute + 'Upload';

        return this.http.post(url, formData);
    }

    getAddressById(id: number): Observable<any> {
        return this.get(this.baseRoute + id);
    }

    export(filter: boolean): Observable<any> {
        if (!filter || this.addressSearchModel === undefined) {
            this.addressSearchModel.page = 0;
            this.addressSearchModel.setStart();
            this.addressSearchModel.pageSize = 0;
        }
        return this.post(this.baseRoute + 'export/', this.addressSearchModel);
    }

    updateSearchModel(modelChangeDirection: ModelChangeDirection): void {

        let index = this.dataStore.data.indexOf(this.dataStore.selectedAddress);
        this.dataStore.selectedAddress = this.dataStore.data[index + modelChangeDirection];

        this.updateCanNavigateRecords();
    }

    updateCanNavigateRecords(): void {
        this.canGoNextAddress = this.canUpdateModel(ModelChangeDirection.Next);
        this.canGoPreviousAddress = this.canUpdateModel(ModelChangeDirection.Previous);
    }

    canUpdateModel(modelChangeDirection: ModelChangeDirection): boolean {
        let index = this.dataStore.data.indexOf(this.dataStore.selectedAddress);
        return this.dataStore.data[index + modelChangeDirection] !== undefined;
    }

    saveNewAddress(address: AddressModel): void {
        this.post(this.baseRoute, address).subscribe(result => {
                let address:AddressModel = JSON.parse(result._body);
                this.dataStore.selectedAddress = address;
                this.updateEntity.emit(address);
            },
            error => {
                alert('There was an error in your address please check and try again');
            });
    }

    saveUpdateAddress(address: AddressModel): void {
        this.patch(this.baseRoute, address).subscribe(result => {
                let a = 'b';
            },
            error => {
                alert('There was an error in your address please check and try again');
            });
    }
}