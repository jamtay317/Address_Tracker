﻿import { Component, OnInit, OnDestroy} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


import { Observable } from 'rxjs/Observable';
import { Subscription } from "rxjs/Subscription";
import 'rxjs/add/observable/forkJoin';

import { AddressSearchModel } from '../models/address-search.model';
import { AddressModel } from '../models/address.model';
import { AddressService } from '../address.service';
import { AddressResultModel } from '../models/address-result.model'
import { ItemDataService } from '../../services/item-data.service';
import { ItemData } from '../../services/models/item-data.model';
import { AddressSearchService } from '../search/address-search.service';
import { ModelChangeDirection } from '../models/enums/model-change-direction.enum';
import { SessionService } from '../../session.service';

@Component({
    selector: 'address-details',
    templateUrl: 'app/addresses/details/address-details.component.html'
})
export class AddressDetailsComponent implements OnInit, OnDestroy {

    id:number;
    address: AddressModel;
    public form:FormGroup;
    searchResults: AddressResultModel[]=[];
    modelChangeDirections:any = ModelChangeDirection;
    displayAllFields: boolean = false;
    displayAllFieldsLabel: string = 'Display All Fields';
    disableAllFields:boolean = true;
    action: Action = Action.ReadOnly;

    actions:any=Action;

    communities: ItemData[] = [];
    muncipalities: ItemData[] = [];
    zipCodes: ItemData[] = [];
    zonings: ItemData[] = [];
    pointTypes: ItemData[] = [];
    powerCompanies: ItemData[] = [];
    directions: ItemData[] = [];
    districts: ItemData[] = [];

    subscriptions:Subscription[]=[];

    constructor(
        private activatedRoute: ActivatedRoute,
        private addressService: AddressService,
        private formBuilder: FormBuilder,
        public itemDataService: ItemDataService,
        public service: AddressSearchService,
        private sessionService:SessionService
    ) {
        this.address = new AddressModel();
    }

    isDisabled(propertyName: string): boolean {
        let isDisabled = true;
        if (this.address.hasOwnProperty(propertyName)) {
            let value = this.address[propertyName];
            isDisabled = value === undefined || value === null || value==='';
        }
        return isDisabled;
    }

    goToOldGps(): void {
        this.openGpsCoordinates(this.address.oldLatitude, this.address.oldLongitude);
    }

    openGpsCoordinates(latitude: number, longitude: number, isdirections?: boolean) {
        let googleLink = '';
        if (!isdirections) {
            googleLink = `http://www.google.com/maps/place/${latitude},${longitude}`;
        } else {
            googleLink = `http://www.google.com/maps/place/dir/${latitude},${longitude}`;
        }
        window.open(googleLink);
    }

    edit(): void {
        this.disableAllFields = false;
        this.action = Action.Update;
    }

    addAddress(): void {
        this.addressService.dataStore.selectedAddress = null;
        this.address = new AddressModel();
        this.clearDataFromForm();
        this.disableAllFields = false;
        this.action = Action.Add;
    }

    ngOnInit(): void {

        this.buildForm();
        this.getData();
        this.addressService.updateCanNavigateRecords();
        let subscription = this.addressService.updateEntity.subscribe((address: AddressModel) => {
            this.form.controls['id'].setValue(address.id);
        });
        this.subscriptions.push(subscription);
    }

    ngOnDestroy(): void {
        for (let subscriton of this.subscriptions) {
            subscriton.unsubscribe();
        }
    }

    buildForm(): void {
        this.form = this.formBuilder.group({
            id: new FormControl({ value: '', disabled: true }),
            totalAddress: ['', Validators.required],
            community: ['', Validators.required],
            muncipality: ['', Validators.required],
            propertyDescription:[''],
            notes:[''],
            longitude: ['', Validators.required],
            latitude: ['', Validators.required],
            parcelNumber:[''],
            zipCode: ['', Validators.required],
            zoning:[''],
            district: [''],
            pointType: ['', Validators.required],
            floodPlane: [''],
            houseNumber: ['', Validators.required],
            appartmentNumber: [''],
            addressStreetName: ['', Validators.required],
            nameOfBusiness: [''],
            county: [''],
            esnNumber: [''],
            subDivision: [''],
            prefixCardinalDirection: [''],
            suffixCardinalDirection: [''],
            streetNumber: ['', Validators.required],
            firstPartOfStreetName: [''],
            streetName: ['', Validators.required],
            powerCompany: [''],
            firstName: [''],
            lastName: [''],
            middleName: [''],
            oldLongitude: [''],
            oldLatitude: [''],
            realKey: [''],
            qPublickLink: [''],
            googleMapsLink: [''],
            directionsLink: [''],
            pictureLink: [''],
            accessoryKey: [''],
            mobileHomeKey : [''],

    });
    }

    getData(): void {
        let subscription = Observable.forkJoin(
            this.itemDataService.getItems('zoning'),
            this.itemDataService.getItems('community'),
            this.itemDataService.getItems('municpality'),
            this.itemDataService.getItems('zipcode'),
            this.itemDataService.getItems('pointtype'),
            this.itemDataService.getItems('powercompany'),
            this.itemDataService.getItems('direction'),
            this.itemDataService.getItems('district')
            
        ).subscribe(result => {
            this.zonings = JSON.parse(result[0]._body);
            this.communities = JSON.parse(result[1]._body);
            this.muncipalities = JSON.parse(result[2]._body);
            this.zipCodes = JSON.parse(result[3]._body);
            this.pointTypes = JSON.parse(result[4]._body);
            this.powerCompanies = JSON.parse(result[5]._body);
            this.directions = JSON.parse(result[6]._body);
            this.districts = JSON.parse(result[7]._body);
        });

        this.subscriptions.push(subscription);

        this.updateViewAddress();
    }

    updateViewAddress(): void {
        this.addressService
            .getAddressById(this.addressService.dataStore.selectedAddress.id)
            .subscribe(result => {
                this.address = JSON.parse(result._body);
                this.addDataToForm();
            });
    }

    onRowClick(event: any) {
        this.service.navigateTo('/addresses/details', event.id);
    }

    clearDataFromForm(): void {
        this.addDataToForm();
       
    }

    addDataToForm(): void {
        this.form.controls['id'].setValue(this.address.id);
        this.form.controls['totalAddress'].setValue(this.address.totalAddress);
        this.form.controls['community'].setValue(this.address.communityId);
        this.form.controls['muncipality'].setValue(this.address.muncipalityId);
        this.form.controls['propertyDescription'].setValue(this.address.propertyDescription);
        this.form.controls['notes'].setValue(this.address.notes);
        this.form.controls['longitude'].setValue(this.address.longitude);
        this.form.controls['latitude'].setValue(this.address.latitude);
        this.form.controls['parcelNumber'].setValue(this.address.parcelNumber);
        this.form.controls['zipCode'].setValue(this.address.zipCodeId);
        this.form.controls['zoning'].setValue(this.address.zoningId);
        this.form.controls['district'].setValue(this.address.district);
        this.form.controls['pointType'].setValue(this.address.pointTypeId);
        this.form.controls['floodPlane'].setValue(this.address.floodPlane);
        this.form.controls['houseNumber'].setValue(this.address.houseNumber);
        this.form.controls['appartmentNumber'].setValue(this.address.appartmentNumber);
        this.form.controls['nameOfBusiness'].setValue(this.address.nameOfBusiness);
        this.form.controls['county'].setValue(this.address.county);
        this.form.controls['esnNumber'].setValue(this.address.esnNumber);
        this.form.controls['subDivision'].setValue(this.address.subDivision);
        this.form.controls['prefixCardinalDirection'].setValue(this.address.prefixCardinalDirectionId);
        this.form.controls['suffixCardinalDirection'].setValue(this.address.suffixCardinalDirectionId);
        this.form.controls['streetNumber'].setValue(this.address.streetNumber);
        this.form.controls['firstPartOfStreetName'].setValue(this.address.firstPartOfStreetName);
        this.form.controls['streetName'].setValue(this.address.streetName);
        this.form.controls['powerCompany'].setValue(this.address.powerCompanyId);
        this.form.controls['firstName'].setValue(this.address.firstName);
        this.form.controls['lastName'].setValue(this.address.lastName);
        this.form.controls['middleName'].setValue(this.address.middleName);
        this.form.controls['oldLongitude'].setValue(this.address.oldLongitude);
        this.form.controls['oldLatitude'].setValue(this.address.oldLatitude);
        this.form.controls['realKey'].setValue(this.address.realKey);
        this.form.controls['qPublickLink'].setValue(this.address.qPublicLink);
        this.form.controls['googleMapsLink'].setValue(this.address.googleMapsLink);
        this.form.controls['directionsLink'].setValue(this.address.directionsLink);
        this.form.controls['pictureLink'].setValue(this.address.pictureLink);
        this.form.controls['accessoryKey'].setValue(this.address.accessoryKey);
        this.form.controls['mobileHomeKey'].setValue(this.address.mobileHomeKey);
        this.form.controls['addressStreetName'].setValue(this.address.addressStreetName);
    }

    getImageUrl(): string {
        let url = '';
        if (this.address !== undefined) {
            url = `url('${this.address.pictureLink}')`;
        }
        return url;
    }

    goBack():void {
       this.service.navigateTo("addresses");
    }

    goToRow(row: any) {
        let selectedAddress = this.addressService.dataStore.data.filter(x => x.id === row.id)[0];
        this.addressService.dataStore.selectedAddress = selectedAddress;
        this.addressService.updateCanNavigateRecords();

        this.addressService
            .getAddressById(this.addressService.dataStore.selectedAddress.id)
            .subscribe(result => {
                this.address = JSON.parse(result._body);
                this.addDataToForm();
            });
    }

    updateModel(modelChangeDirection: ModelChangeDirection): void {
        this.addressService.updateSearchModel(modelChangeDirection);
        this.addressService.updateCanNavigateRecords();
        this.updateViewAddress();
    }

    onDisplayAllFields(): void {
        this.displayAllFields = !this.displayAllFields;

        if (this.displayAllFields) {
            this.displayAllFieldsLabel = 'Collapse All Fields';
        } else {
            this.displayAllFieldsLabel = 'Display All Fields';
        }
    }

    save(): void {
        this.patchValues();
        switch (this.action) {
            case Action.Add:
                this.addressService.saveNewAddress(this.address);
                break;
            case Action.Update:
                this.addressService.saveUpdateAddress(this.address);
                break;

            default:
                console.log('Action cannot be ReadOnly To Save');
        }
        this.action = Action.ReadOnly;
        this.disableAllFields = true;
    }
    patchValues(): void {
        this.address.totalAddress=this.form.controls['totalAddress'].value;
        this.address.communityId=this.form.controls['community'].value;
        this.address.muncipalityId = this.form.controls['muncipality'].value;
        this.address.propertyDescription = this.form.controls['propertyDescription'].value;
        this.address.notes = this.form.controls['notes'].value;
        this.address.longitude = this.form.controls['longitude'].value;
        this.address.latitude = this.form.controls['latitude'].value;
        this.address.parcelNumber = this.form.controls['parcelNumber'].value;
        this.address.zipCodeId = this.form.controls['zipCode'].value;
        this.address.zoningId = this.form.controls['zoning'].value;
        this.address.district = this.form.controls['district'].value;
        this.address.pointTypeId = this.form.controls['pointType'].value;
        this.address.floodPlane = this.form.controls['floodPlane'].value;
        this.address.houseNumber = this.form.controls['houseNumber'].value;
        this.address.appartmentNumber = this.form.controls['appartmentNumber'].value;
        this.address.nameOfBusiness = this.form.controls['nameOfBusiness'].value;
        this.address.county = this.form.controls['county'].value;
        this.address.esnNumber = this.form.controls['esnNumber'].value;
        this.address.subDivision = this.form.controls['subDivision'].value;
        this.address.prefixCardinalDirectionId = this.form.controls['prefixCardinalDirection'].value;
        this.address.suffixCardinalDirectionId = this.form.controls['suffixCardinalDirection'].value;
        this.address.streetNumber = this.form.controls['streetNumber'].value;
        this.address.firstPartOfStreetName = this.form.controls['firstPartOfStreetName'].value;
        this.address.streetName = this.form.controls['streetName'].value;
        this.address.powerCompanyId = this.form.controls['powerCompany'].value;
        this.address.firstName = this.form.controls['firstName'].value;
        this.address.lastName = this.form.controls['lastName'].value;
        this.address.middleName = this.form.controls['middleName'].value;
        this.address.oldLongitude = this.form.controls['oldLongitude'].value;
        this.address.oldLatitude = this.form.controls['oldLatitude'].value;
        this.address.realKey = this.form.controls['realKey'].value;
        this.address.qPublicLink = this.form.controls['qPublickLink'].value;
        this.address.googleMapsLink = this.form.controls['googleMapsLink'].value;
        this.address.directionsLink = this.form.controls['directionsLink'].value;
        this.address.pictureLink = this.form.controls['pictureLink'].value;
        this.address.accessoryKey = this.form.controls['accessoryKey'].value;
        this.address.mobileHomeKey = this.form.controls['mobileHomeKey'].value;
        this.address.addressStreetName = this.form.controls['addressStreetName'].value;

    }
}

export enum Action {
    ReadOnly = 0,
    Add = 1,
    Update=2
}