﻿import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule} from '@angular/common';

import { AddressComponent } from './address.component';
import { AddressDetailsComponent } from './details/address-details.component';
import { AddressSearchComponent } from './search/address-search.component';
import { AddressSearchService } from './search/address-search.service';
import { AddressService } from './address.service';
import { ExportFileComponent } from './export/export-file.component';
import { ImportFileComponent } from './import/import-file.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        SharedModule
    ],
    declarations: [
        AddressComponent,
        AddressDetailsComponent,
        AddressSearchComponent,
        ExportFileComponent,
        ImportFileComponent,
    ],
    exports: [
        AddressComponent,
        AddressDetailsComponent,
        AddressSearchComponent,
        ExportFileComponent,
        ImportFileComponent
    ],
    providers: [
     ]
})
export class AddressModule { }