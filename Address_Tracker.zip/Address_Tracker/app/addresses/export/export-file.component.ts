﻿import { Component, OnInit } from '@angular/core';

import { AddressResultModel } from '../models/address-result.model'
import { AddressSearchModel } from '../models/address-search.model';
import { AddressService } from '../address.service';

@Component({
    selector: 'export-file',
    templateUrl: 'app/addresses/export/export-file.component.html'
})
export class ExportFileComponent implements OnInit {

    constructor(private addressService:AddressService) { }

    filterOn: boolean = true;
    filterLabel: string = 'On';
    filterDisabled:boolean = false;

    searchResults:AddressResultModel[]=[];
    startSearchParameters: AddressSearchModel;
    activeSearhParameters:AddressSearchModel;
    canPage:boolean=false;


    ngOnInit(): void {
        this.startSearchParameters = this.addressService.addressSearchModel;
        this.activeSearhParameters = new AddressSearchModel();

        if (this.addressService.addressSearchModel === undefined) {
            this.addressService.addressSearchModel = new AddressSearchModel();
            this.addressService.addressSearchModel.pageSize = 0;
            this.filterLabel = 'Off';
            this.filterOn = false;
            this.filterDisabled = true;
        }

        this.refreshData();
    }

    onExport(): void {
        this.addressService.export(this.filterOn).subscribe(result => {
                let str = result._body;
                let uri = 'data:text/csv;charset=utf-8,' + str;

                var downloadLink = document.createElement("a");
                downloadLink.href = uri;
                downloadLink.download = "results.csv";

                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            },
            error => {
                alert('Something went wrong.');
            });
    }

    onFilter(): void {
        this.filterOn = !this.filterOn;
        this.filterLabel = (this.filterOn) ? 'On' : 'Off';

        if (this.filterOn) {
            this.addressService.addressSearchModel = this.startSearchParameters;
        } else {
            this.addressService.addressSearchModel = this.activeSearhParameters;
        }
        
        this.refreshData();
    }

    refreshData(): void {
        if (!this.canPage) {
            this.addressService.addressSearchModel.pageSize = 0;
        }

        this.addressService.getSearchItems();
    }

    onPageChange(event: any):void {
        this.addressService.addressSearchModel.page = event;
        this.addressService.addressSearchModel.setStart();

        this.refreshData();
    }
}