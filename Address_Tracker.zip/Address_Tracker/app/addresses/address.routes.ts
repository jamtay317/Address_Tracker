﻿import { Routes } from '@angular/router';

import { AddressComponent } from './address.component';
import {AddressDetailsComponent} from './details/address-details.component';
import { AddressSearchComponent } from './search/address-search.component';
import { ExportFileComponent } from './export/export-file.component';
import { ImportFileComponent} from './import/import-file.component';

export const AddressRoutes: Routes=[
    {
        path: 'addresses', component: AddressComponent, children: [
            { path:'', redirectTo:'search', pathMatch:'full' },
            { path: 'details/:id', component: AddressDetailsComponent},
            { path: 'details', component: AddressDetailsComponent},
            { path: 'export', component: ExportFileComponent },
            { path: 'import', component: ImportFileComponent },
            { path: 'search', component: AddressSearchComponent },
        ]
    }
];