﻿import { Component } from '@angular/core';
import { Routes } from '@angular/router';

@Component({
    selector: 'address',
    templateUrl: 'app/addresses/address.component.html'
})
export class AddressComponent {

    constructor() {}

    onImport(): void {

    }
}