﻿import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
import { AddressService } from '../address.service';

@Injectable()
export class AddressSearchService {

    constructor(private router: Router, public addressService:AddressService) { }

    navigateTo(path: string, id?: number): void {
        if (id) {
            this.router.navigate([path, id]);
        } else {
            this.router.navigate([path]);
        }
        
    }

}