﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';

import { Subscription } from 'rxjs';

import { AddressSearchModel } from '../models/address-search.model';
import { AddressService } from '../address.service';
import { AddressSearchService } from './address-search.service';

@Component({
    selector: 'address-search',
    templateUrl: 'app/addresses/search/address-search.component.html'
})
export class AddressSearchComponent implements OnInit, OnDestroy {

    name:string='address search.';
    model:AddressSearchModel;
    canPage: boolean = false;
    isLoading:boolean=false;

    subscription:Subscription;

    constructor(private addressService: AddressService,
        private router: Router,
        public service: AddressSearchService,

    ) { }

    ngOnInit(): void {
        this.subscription = this.addressService.searchComplete.subscribe(() => this.isLoading = false);
        this.model = new AddressSearchModel();
        this.getData();
    }

    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }

    getData(): void {

    }

    onClear(): void {
        this.addressService.dataStore.data = [];
        this.addressService.hasResults = false;
        this.addressService.hasSearched = false;
    }

    onSearch(): void {
        this.isLoading = true;
        this.model.setStart();
        this.addressService.addressSearchModel = this.model;

        if (!this.canPage) {
            this.addressService.addressSearchModel.pageSize = 0;
        }

        this.addressService.getSearchItems();
    }
    onPageChange(page:number): void {
        this.model.page = page;
        this.onSearch();
    }

    onRowClick(event: any) {
        this.service.navigateTo('/addresses/details',event.id);
    }
}