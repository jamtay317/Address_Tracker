﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { BaseService } from './shared/services/service-base.service';

import * as moment from 'moment';

@Injectable()
export class SessionService extends BaseService {

    constructor(protected http:Http) {
        super(http);
    }
    role:string = 'READER';
    session:any;

    init(): void {
        this.session = JSON.parse(this.getStorageItem('session'));
        if (this.session) {
            this.role = this.session.role;
        }
    }

    logout(): void {
        this.get('./login/Logout?username=' + this.session.username).subscribe(result => {}, error=> new Error(error));
    }

    hasSessionInfo(): boolean {
        return this.session!== undefined && this.session!==null ;
    }

    getStorageItem(storageItem: string): string {
        var item = localStorage.getItem(storageItem);
        console.log(item);
        return item;
    }

    getUsername(): string {
        this.setSession();
        if (this.session === undefined) return undefined;
        
        return this.session.username;
    }

    isSessionValid(): boolean {
        
        if (this.session === undefined || this.session === null) return false;

        let expires = localStorage.getItem('expires');
        let expireDate = moment(expires);

        if (expireDate < moment()) {
            this.clearSessionInfo();
            return false;
        }

        return moment(this.session.sessionExpires).diff(moment(), 'days') > 0;
    }

    clearSessionInfo(): void {
        this.removeItem('username');
        this.removeItem('expires');
        this.removeItem('role');
        this.removeItem('session');
    }

    removeItem(itemName: string): void {
        localStorage.removeItem(itemName);
    }

    private setUserRole(): void {
        let role = this.getStorageItem('role');
        this.role = role;
    }

    private setSession() {
        var sessionJson = this.getStorageItem('session');
        if (sessionJson !== undefined) {
            sessionJson = sessionJson.replace('session=', '');
            this.session = JSON.parse(sessionJson);
        }
    }
}