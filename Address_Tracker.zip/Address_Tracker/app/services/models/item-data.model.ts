﻿export class ItemData {
    id: number;
    name:string;
}