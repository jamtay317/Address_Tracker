﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs';

import { BaseService } from '../shared/services/service-base.service';

@Injectable()
export class ItemDataService extends BaseService {

    constructor(public  http: Http) {
        super(http);
    }

    /*
     * returns all of the items from the base controller that is 
     * passed in
     */
    getItems(baseUrl: string): Observable<any> {
        return this.get('api/'+baseUrl);
    }
}