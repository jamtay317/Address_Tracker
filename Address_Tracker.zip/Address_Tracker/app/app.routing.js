"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var address_routes_1 = require("./addresses/address.routes");
var admin_routes_1 = require("./admin/admin.routes");
exports.AppRoutes = address_routes_1.AddressRoutes.concat(admin_routes_1.AdminRoutes, [
    { path: '', pathMatch: 'full', redirectTo: '/addresses/search' }
]);
//# sourceMappingURL=app.routing.js.map