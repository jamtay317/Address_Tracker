﻿import { Routes } from "@angular/router";

import { AddressRoutes } from './addresses/address.routes';
import { AdminRoutes } from './admin/admin.routes';

export const AppRoutes: Routes = [
    ...AddressRoutes,
    ...AdminRoutes,
    { path: '', pathMatch: 'full', redirectTo:'/addresses/search'}
];