﻿import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AddressModule } from './addresses/address.module';
import { AdminModule } from './admin/admin.module';
import { AppConfig } from './app.config';
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routing';
import { AddressService } from './addresses/address.service';
import { AddressSearchService } from './addresses/search/address-search.service';
import { ItemDataService } from './services/item-data.service';
import { SessionService } from './session.service'
import { SharedModule } from './shared/shared.module';


@NgModule({
    imports: [
        AddressModule,
        AdminModule,
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpModule,
        ReactiveFormsModule,
        RouterModule.forRoot(AppRoutes, { enableTracing: true }),
        SharedModule
    ],
    declarations: [
        AppComponent
    ],
    bootstrap: [
        AppComponent
    ],
    providers: [

        AddressService,
        AddressSearchService,
        AppConfig,
        { provide: LocationStrategy, useClass: HashLocationStrategy },
        ItemDataService,
        SessionService
    ]

})
export class AppModule { }