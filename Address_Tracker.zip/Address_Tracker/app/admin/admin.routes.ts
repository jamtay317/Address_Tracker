﻿import { Routes } from "@angular/router";

import { AdminComponent } from './admin.component';
import { CheckMessagesComponent } from './messages/check-messages/check-messages.component';
import { ContactUsComponent } from './messages/contact-us/contact-us.component';
import { RegisterUserComponent } from './users/register-user.component';
import { UsersComponent } from './users/users.component';

export const AdminRoutes:Routes = [
    {
        path: 'admin', component: AdminComponent, children: [
            { path:'check-messages', component:CheckMessagesComponent },
            { path:'contact-us', component:ContactUsComponent},
            { path: 'register', component: RegisterUserComponent },
            { path: 'manage-user', component:UsersComponent}
        ]
    }
]