﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Observable } from 'rxjs';

import { Message } from'./models/message.model';
import { BaseService } from '../../shared/services/service-base.service';


@Injectable()
export class MessagesService extends BaseService {

    constructor(http: Http) {
        super(http);
    }

    send(message: Message): Observable<any> {
        return this.post('message/contactus', message);
    }

    getMessages(): Observable<any> {
        return this.get('message/checkMessages');
    }

    getSelectedMessage(id: number): Observable<any> {
        return this.get(`message/selectMessage/${id}`);
    }
}