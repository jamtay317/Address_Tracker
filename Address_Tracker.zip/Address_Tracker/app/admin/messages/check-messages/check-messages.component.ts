﻿import { Component, OnInit } from '@angular/core';

import { MessagesService } from '../messages.service';
import { Message } from '../models/message.model';
import { MessageDto } from '../models/messageDto.model';

@Component({
    selector: 'check-messages',
    templateUrl: 'app/admin/messages/check-messages/check-messages.component.html',
    styleUrls: [
        './Less/messages/message-viewer.min.css'
        ]
})
export class CheckMessagesComponent implements OnInit {

    constructor(private messageService:MessagesService) {}

    messages:MessageDto[]=[];

    selectedMessage:Message;

    ngOnInit(): void {
        this.getData();
    }

    getData(): void {
        this.messageService.getMessages().subscribe(result => {
            let checkMessageViewModel = JSON.parse(result._body);
            this.messages = checkMessageViewModel.messages;
        });
    }

    getMessageDetails(id: number) {
        this.messageService.getSelectedMessage(id).subscribe(result => {
            let checkMessageViewModel = JSON.parse(result._body);
            this.messages = checkMessageViewModel.messages;
            this.selectedMessage = checkMessageViewModel.selectedMessage;
        });
    }
}