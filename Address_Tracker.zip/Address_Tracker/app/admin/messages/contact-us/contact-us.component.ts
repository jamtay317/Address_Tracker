﻿import { Component, OnInit, Input } from '@angular/core';

import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

import { MessagesService } from '../messages.service';
import { Message } from '../models/message.model';

@Component({
    selector: 'contact-us',
    templateUrl: 'app/admin/messages/contact-us/contact-us.component.html',
    styleUrls: ['./Less/messages/messages.min.css']
})
export class ContactUsComponent implements OnInit {

    constructor(
        private formBuilder: FormBuilder,
        private messagesService: MessagesService
    ) { }

    form: FormGroup;
    private _model:Message;
    @Input()
    get model(): Message {
        return this._model;
    }
    set model(value:Message) {
        this._model = value;
        if (this.form === undefined) {
            this.buildForm();
        }
        this.updateUi();
    }

    @Input() showSaveButtons:boolean = true;

    ngOnInit(): void {
        this.model = new Message();
        this.buildForm();
        this.updateUi();
    }

    buildForm(): void {
        this.form = this.formBuilder.group({
            name: new FormControl('', [Validators.required]),
            phone: new FormControl('', [Validators.required]),
            email: new FormControl('', [Validators.required]),
            subject: new FormControl('', [Validators.required]),
            message: new FormControl('', [Validators.required]),
        });
    }

    updateModel(): void {
        this.model.name = this.form.controls['name'].value;
        this.model.phone = this.form.controls['phone'].value;
        this.model.emailAddress = this.form.controls['email'].value;
        this.model.subject = this.form.controls['subject'].value;
        this.model.notificationMessage = this.form.controls['message'].value;
    }

    updateUi():void {
        this.form.controls['name'].setValue(this.model.name);
        this.form.controls['phone'].setValue(this.model.phone);
        this.form.controls['email'].setValue(this.model.emailAddress);
        this.form.controls['subject'].setValue(this.model.subject);
        this.form.controls["message"].setValue(this.model.notificationMessage);
    }

    send(): void {

        this.updateModel();

        this.messagesService.send(this.model).subscribe(result => {
            let a = 'b';
        },
        error => {
            alert('There was an error, please insure all files are filled out');
        });

    }

    cancel(): void {
        this.form.controls['message'].setValue('');
        this.form.controls['subject'].setValue('');
    }

    isControlInvalid(controlName: string): boolean {
        return this.form.controls[controlName].invalid &&
               this.form.controls[controlName].touched &&
               this.showSaveButtons;
    }
}