﻿export class MessageDto {
    id: number;
    subject: string = '';
    isRead: boolean = false;
    dateSent: Date;
    senderName:string='';
}