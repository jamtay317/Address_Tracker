﻿export class Message {
    name: string = '';
    phone: string = '';
    emailAddress: string = '';
    subject: string = '';
    notificationMessage:string='';
}