﻿export class UserModel {
    id: number;
    firstName: string;
    lastName: string;
    username: string;
    password: string;
    emailAddress: string;
    userRights: string;
    hasAccess:boolean;
}