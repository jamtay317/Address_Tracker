﻿export class UserDto {
    id: number;
    firstName: string;
    lastName:string;
}