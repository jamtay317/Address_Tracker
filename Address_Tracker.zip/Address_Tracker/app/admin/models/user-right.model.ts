﻿export class UserRight {
    name:string;
}