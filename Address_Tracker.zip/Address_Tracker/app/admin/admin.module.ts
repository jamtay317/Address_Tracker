﻿import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AdminComponent } from './admin.component';
import { CheckMessagesComponent } from './messages/check-messages/check-messages.component';
import { ContactUsComponent } from './messages/contact-us/contact-us.component';
import { MessagesService} from './messages/messages.service';
import { RegisterUserComponent } from './users/register-user.component';
import { SharedModule } from '../shared/shared.module';
import { UsersComponent } from './users/users.component';
import { UsersService} from './users/users.service';


@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        SharedModule
    ],
    declarations: [
        AdminComponent,
        CheckMessagesComponent,
        ContactUsComponent,
        RegisterUserComponent,
        UsersComponent
    ],
    providers: [
        MessagesService,
        UsersService
    ],
    exports: [
        AdminComponent,
        CheckMessagesComponent,
        ContactUsComponent,
        RegisterUserComponent,
        UsersComponent
    ]
})
export class AdminModule { }