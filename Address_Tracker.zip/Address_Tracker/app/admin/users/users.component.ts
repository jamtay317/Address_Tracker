﻿import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';

import { UserDto } from '../models/user-dto.model';
import { UserModel } from '../models/user.model';
import { UserRight } from '../models/user-right.model';
import { UsersService } from './users.service';
import { SelectionType } from '../../shared/controls/reactive/at-dropdown.component';

@Component({
    selector: 'users',
    templateUrl: 'app/admin/users/users.component.html'
})
export class UsersComponent implements OnInit {

    userDtos: UserDto[] = [];
    selectedUser: UserModel = null;
    form: FormGroup;
    privileges: UserRight[] = [];
    dropdownSelectionTypes: any = SelectionType;

    constructor(
        private userService: UsersService,
        private formBuilder: FormBuilder
    ) { }

    ngOnInit(): void {
        this.buildForm();
        this.getData();
    }


    buildForm(): void {
        this.form = this.formBuilder.group({
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            userName: ['', Validators.required],
            email: ['', Validators.required],
            privileges: ['', Validators.required],
            hasAccess: new FormControl()
        });
    }

    getData(): void {
        Observable.forkJoin(
            this.userService.getUsers(),
            this.userService.getPrivileges()
        ).subscribe(result => {
            this.userDtos = JSON.parse(result[0]._body);
            this.privileges = JSON.parse(result[1]._body);
        });
    }

    onUserChanged(userDto: UserDto): void {
        this.userService.getUser(userDto.id).subscribe(result => {
            this.selectedUser = JSON.parse(result._body);
            this.updateForm();
        });
    }

    updateForm(): void {
        this.form.controls['firstName'].setValue(this.selectedUser.firstName);
        this.form.controls['lastName'].setValue(this.selectedUser.lastName);
        this.form.controls['userName'].setValue(this.selectedUser.username);
        this.form.controls['email'].setValue(this.selectedUser.emailAddress);
        this.form.controls['privileges'].setValue(this.selectedUser.userRights);
        this.form.controls['hasAccess'].setValue(this.selectedUser.hasAccess);
    }

    save(): void {

        this.selectedUser.firstName = this.form.controls['firstName'].value;
        this.selectedUser.lastName = this.form.controls['lastName'].value;
        this.selectedUser.username = this.form.controls['userName'].value;
        this.selectedUser.emailAddress = this.form.controls['email'].value;
        this.selectedUser.userRights = this.form.controls['privileges'].value;
        this.selectedUser.hasAccess = this.form.controls['hasAccess'].value;

        this.userService.updateUser(this.selectedUser).subscribe(result => {
            alert('User Saved');
        },
            error => {
                alert('There was an error, please check the user for valid data');
            });
    }
}