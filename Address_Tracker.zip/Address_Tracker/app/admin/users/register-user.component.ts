﻿import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

import { UserModel } from '../models/user.model';
import { UsersService } from './users.service';


@Component({
    selector: 'register-user',
    templateUrl: 'app/admin/users/register-user.component.html'
})
export class RegisterUserComponent implements OnInit {

    form: FormGroup;

    get isValid() {
        return this.passwordsMatch();
    }

    passwordsMatch()  {
        let isValid = false;
        if (this.form) {
            isValid = this.form.controls["password"].value === this.form.controls['confirmPassword'].value;
        }
        return isValid;
    };

    constructor(private formBuilder:FormBuilder,private  usersService:UsersService) {}

    ngOnInit(): void {
        this.buildForm();
    }

    buildForm(): void {
        this.form = this.formBuilder.group({
            firstName: ['', [Validators.required, Validators.maxLength(150)]],
            lastName: ['', [Validators.required, Validators.maxLength(150)]],
            username: ['', [Validators.required, Validators.maxLength(150)]],
            email: ['', [Validators.required, Validators.maxLength(150)]],
            password: ['', [Validators.required]],
            confirmPassword: ['', [Validators.required]]
        });
    }

    save(): void {
        
        let model = new UserModel();
        model.password = this.form.controls["password"].value;;
        model.firstName = this.form.controls["firstName"].value;
        model.lastName = this.form.controls["lastName"].value;
        model.emailAddress = this.form.controls["email"].value;
        model.username = this.form.controls["username"].value;

        this.usersService.registerNewUser(model).subscribe(result => {});
    }
}