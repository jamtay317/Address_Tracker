﻿import { Injectable } from '@angular/core';
import {Http} from '@angular/http';

import {Observable} from 'rxjs';

import { BaseService } from '../../shared/services/service-base.service';
import {UserModel} from '../models/user.model';


@Injectable()
export class UsersService extends BaseService {

    baseUrl:string = 'api/user/';

    constructor(protected  http: Http) {
        super(http);
    }

    registerNewUser(user: UserModel): Observable<any> {

        return this.post(this.baseUrl + 'registerUser', user);
    }

    getUsers(): Observable<any> {
        return this.get(this.baseUrl);
    }

    getUser(id: number): Observable<any> {
        return this.get(this.baseUrl + id);
    }

    getPrivileges(): Observable<any> {
        return this.get(this.baseUrl + 'GetPrivileges');
    }

    updateUser(user: UserModel): Observable<any> {
        return this.post(this.baseUrl + "UpdateUser", user);
    }
}