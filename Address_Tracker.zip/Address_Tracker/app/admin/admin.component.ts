﻿import { Component, OnInit} from '@angular/core';

@Component({
    selector: 'admin',
    templateUrl: 'app/admin/admin.component.html'
})
export class AdminComponent implements OnInit {

    name:string='Admin Component';

    ngOnInit(): void {
        
    }
}