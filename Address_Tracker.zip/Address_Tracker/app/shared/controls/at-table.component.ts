﻿import {
    AfterViewInit,
    ChangeDetectorRef,
    Component,
    ContentChildren,
    ElementRef,
    EventEmitter,
    Input,
    Output,
    QueryList,
    ViewChild,
} from '@angular/core';

import { AtTextColumn } from'./directives/table-columns/at-text-column.directicve';

@Component({
    selector: 'at-table',
    templateUrl: 'app/shared/controls/at-table.component.html'
})
export class AtTableComponent implements  AfterViewInit {

    columnType:string='text';
    columns: any[] = [];
    page: number = 0;
    @ContentChildren(AtTextColumn) elements:QueryList<any>;

    selectedRowLocal: any = null;
    @Input()
    set selectedRow(value:any) {
        this.selectedRowLocal = value;
        this.scrollToRow();
    }
    get selectedRow() {
        return this.selectedRowLocal;
    }
    @Output() selectedRowChange:EventEmitter<any> = new EventEmitter<any>();

    @Input() rows: any[] = [];
    @Input() canPage:boolean=false;

    @Output() selectionChanged: EventEmitter<any> = new EventEmitter<any>();
    @Output() dblClick: EventEmitter<any> = new EventEmitter();
    @Output() pageChange: EventEmitter<any> = new EventEmitter();

    @Input() service:any;

    constructor(private changeDectectorRef:ChangeDetectorRef) {}
    
    ngAfterViewInit(): void {
        for (let directive of this.elements.toArray()) {
            this.columns.push(directive);
        }
        this.changeDectectorRef.detectChanges();
    }

    onPageChange(pageChangeValue: number): void {
        this.page += pageChangeValue;
        this.pageChange.emit(this.page);
    }

    onSelectedRow(row: any): void {
        this.selectedRowLocal = row;
        this.selectedRowChange.emit(row);
        this.selectionChanged.emit(row);
    }

    onDblClick(row: any):void {
        this.selectedRowLocal = row;
        this.selectedRowChange.emit(row);
        this.dblClick.emit(row);
    }

    onButtonClick(row: any, column: any): void {
        this.selectedRow = row;
        this.selectedRowChange.emit(row);
        this.selectionChanged.emit(row);

        if (column.clickEvent !== undefined) {
            column.clickEvent(row);
        }
    }

    scrollToRow(): void {
        let index = this.rows.indexOf(this.selectedRow);
        let element=document.getElementById(`${index}`);
        if (element) {
            element.scrollIntoView(false);
        }
    }
}