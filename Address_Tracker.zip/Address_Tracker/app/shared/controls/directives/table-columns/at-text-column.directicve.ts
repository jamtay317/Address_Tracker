﻿import { Directive, Input } from '@angular/core';

@Directive({
    selector:'at-text-column'
})
export class AtTextColumn {
    @Input() header: string = '';
    @Input() displayMemberPath = '';

    columnType: string = 'text';

    getHtmlMarkup(row:any, column:any): string {
        let value = '';

        if (row.hasOwnProperty(column.displayMemberPath)) {
            value = row[column.displayMemberPath];
        }

        return value;
    }
}