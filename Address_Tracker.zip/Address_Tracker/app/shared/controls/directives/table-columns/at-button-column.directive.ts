﻿import { Directive, Input, forwardRef } from '@angular/core';

import { AtTextColumn } from './at-text-column.directicve';

@Directive({
    selector: 'at-button-column',
    providers: [{provide:AtTextColumn,useExisting:forwardRef(()=>AtButtonColumn)}]
})
export class AtButtonColumn extends AtTextColumn {
    columnType:string='button';
    @Input() clickEvent: Function;
    @Input() icon: string;
    @Input() service:any;

    onClick(): void {
        alert('hello');
    }

    getHtmlMarkup(row: any, column: any): string {
        let html: string = `<a class="btn btn-primary" (click)="onClick()">Click</a>`;
        return html;
    }
}