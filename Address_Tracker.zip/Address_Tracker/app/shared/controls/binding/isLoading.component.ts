﻿import { Component, Input } from '@angular/core';

@Component({
    selector: 'is-loading',
    templateUrl: 'app/shared/controls/binding/isLoading.component.html',
    styleUrls:['Less/controls/isLoading.min.css']
})
export class IsLoadingComponent {
    @Input() isLoading:boolean;
}