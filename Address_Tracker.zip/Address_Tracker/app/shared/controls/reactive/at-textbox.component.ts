﻿import { Component, forwardRef } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { AtBaseControl } from './bases/at-control-base';


@Component({
    selector: 'at-textbox',
    templateUrl: 'app/shared/controls/reactive/at-textbox.component.html',
    providers: [{
            provide: NG_VALUE_ACCESSOR,
            multi: true,
            useExisting:forwardRef(()=>AtTextBoxComponent)
        }]
})
export class AtTextBoxComponent extends AtBaseControl {
    
}