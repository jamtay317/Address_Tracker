﻿import { Component, forwardRef, Input, DoCheck, ChangeDetectorRef } from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { AtBaseControl } from './bases/at-control-base';

@Component({
    selector: 'at-dropdown',
    templateUrl: 'app/shared/controls/reactive/at-dropdown.component.html',
    providers: [{
        provide: NG_VALUE_ACCESSOR,
        multi: true,
        useExisting: forwardRef(() => AtDropDown)
    }]
})
export class AtDropDown extends AtBaseControl implements DoCheck {

    constructor(private changeDectorRef: ChangeDetectorRef) {
        super();
    }

    selectedItem:any;
    
    @Input() displayMemberPath: string = '';
    @Input() valueMemberPath: string = '';
    @Input() disabled:boolean = false;

    @Input() selectionType:SelectionType = SelectionType.Property;
    
    private _itemsSource:any[]=[];
    @Input()
    get itemsSource() {
        return this._itemsSource;
    }
    set itemsSource(value) {
        this._itemsSource = value;
        this.getDisplayValue();
    }

    getDisplayValue(): string {
        return this.getValue(this.selectedItem);
    }

    ngDoCheck(): void {
        let item = this.itemsSource.filter(x => x[this.valueMemberPath] === this._value)[0];
        if (item !== this.selectedItem) {
            this.selectedItem = item;
            this.changeDectorRef.detectChanges();
        }
        
    }

    writeValue(value: any): void {
        if (this.selectionType === SelectionType.Property) {
            if (value !== undefined) {
                this._value = value;
            }

            this.selectedItem = this.itemsSource.filter(x => x[this.valueMemberPath] === this._value)[0];
            this.getDisplayValue();
        }
    }

    getValue(item: any): any {
        let value = '';
        if (typeof item === 'string') {
            return item;
        }

        if (item && item.hasOwnProperty(this.displayMemberPath)) {
            value = item[this.displayMemberPath];
        }
        return value;
    }

    onChanges(event: any): void {
        this.value = event;
        this.selectedItem = event;

        if (this.selectionType === SelectionType.Property && this.itemsSource.length > -1 && this._value) {
            this._value = event[this.valueMemberPath];
        }

        this.onChange(this.value);
    }
}

export enum SelectionType {
    Item = 1,
    Property=2
}