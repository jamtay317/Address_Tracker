﻿import { Component, forwardRef} from "@angular/core";
import { NG_VALUE_ACCESSOR } from "@angular/forms";
import { AtBaseControl }from './bases/at-control-base';

@Component({
    selector: 'at-checkbox',
    templateUrl: 'app/shared/controls/reactive/at-checkbox.component.html',
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            multi: true,
            useExisting: forwardRef(() => AtCheckBox)

        }]
})
export class AtCheckBox extends AtBaseControl { 
}