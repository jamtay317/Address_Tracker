﻿import { Input} from "@angular/core";
import { ControlValueAccessor } from "@angular/forms";

export abstract class AtBaseControl implements ControlValueAccessor {
    @Input() label: string = '';
    @Input('value') _value = '';
    @Input() disabled: boolean = false;
    onChange: any = () => { };
    onTouched: any = () => { };

    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
        this.onChange(value);
        this.onTouched();
    }

    writeValue(value: any): void {
        this.value = value;
    }

    registerOnChange(fn: any): void {
        this.onChange = fn;
    }

    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }

    onChanges(event: any): void {
        this.value = event.currentTarget.value;
    }
}