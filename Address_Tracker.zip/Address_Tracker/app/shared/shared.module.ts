﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AtButtonColumn } from './controls/directives/table-columns/at-button-column.directive';
import { AtCheckBox } from "./controls/reactive/at-checkbox.component";
import { AtDropDown } from './controls/reactive/at-dropdown.component'
import { AtTableComponent } from './controls/at-table.component';
import { AtTextBoxComponent } from "./controls/reactive/at-textbox.component";
import { AtTextColumn } from './controls/directives/table-columns/at-text-column.directicve';
import { EqualValidator } from './validators/same-values.validator';
import { IsLoadingComponent } from './controls/binding/isLoading.component';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [
        AtButtonColumn,
        AtCheckBox,
        AtDropDown,
        AtTableComponent,
        AtTextBoxComponent,
        AtTextColumn,
        IsLoadingComponent,
        EqualValidator,
        
    ],
    exports: [
        AtButtonColumn,
        AtCheckBox,
        AtDropDown,
        AtTableComponent,
        AtTextBoxComponent,
        AtTextColumn,
        EqualValidator,
        IsLoadingComponent,
    ]
})
export class SharedModule { }