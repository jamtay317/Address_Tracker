﻿import { Injectable } from '@angular/core';
import { Http, RequestOptionsArgs, Headers } from '@angular/http';

import { Observable } from 'rxjs';

Injectable()
export abstract class BaseService {
    constructor(
        protected http: Http
    ) { }

    
    protected get(url: string): Observable<any> {
        return this.http.get(url);
    }

    protected patch(url: string, body: any): Observable<any> {
        let requestOptions = this.getHeaders();

        return this.http.patch(url, body, requestOptions);
    }

    protected post(url: string, body: any): Observable<any> {
        let requestOptions = this.getHeaders();

        return this.http.post(url, body, requestOptions);
    }

    protected  getHeaders(): RequestOptionsArgs {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        let requestOptions = {
            headers: headers
        };
        return requestOptions;
    }
}