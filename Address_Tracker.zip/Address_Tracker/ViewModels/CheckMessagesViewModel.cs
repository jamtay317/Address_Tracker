﻿using System.Collections.Generic;
using Address_Tracker.Models.Dtos;

namespace Address_Tracker.ViewModels
{
    public class CheckMessagesViewModel
    {
        public CheckMessagesViewModel()
        {
            Messages = new List<MessageDto>();
        }
        public IEnumerable<MessageDto> Messages { get; set; }

        public MessageViewModel SelectedMessage { get; set; }

    }
}