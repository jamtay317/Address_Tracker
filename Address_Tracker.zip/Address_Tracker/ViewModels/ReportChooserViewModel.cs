﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Address_Tracker.Models.Dtos;

namespace Address_Tracker.ViewModels
{
    public class ReportChooserViewModel
    {
        public ReportChooserViewModel()
        {
            ReportDtos = new List<ReportDto>();
        }

        public string SelectedReport { get; set; }

        public List<ReportDto> ReportDtos { get; set; }
    }
}