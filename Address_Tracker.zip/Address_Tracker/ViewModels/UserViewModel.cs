﻿using System.ComponentModel.DataAnnotations;

namespace Address_Tracker.ViewModels
{
    public class UserViewModel
    {
        [Required(ErrorMessage = "Username is required")]
        public string Username { get; set; }


        [Required(ErrorMessage = "Password Is Required")]
        public string Password { get; set; }
    }
}