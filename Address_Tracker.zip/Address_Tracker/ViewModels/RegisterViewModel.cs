﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Address_Tracker.ViewModels
{
    public class RegisterViewModel
    {
        public bool AlreadyRegisterd { get; set; }

        [Required(ErrorMessage = "Username is required")]
        [StringLength(maximumLength: 50, ErrorMessage = "Username can only have 50 characters")]
        public string Username { get; set; }

        [EmailAddress]
        [StringLength(maximumLength: 150, ErrorMessage = "Email can only have 150 characters")]
        public string  Email { get; set; }

        [Required(ErrorMessage = "First Name is required")]
        [StringLength(maximumLength: 50, ErrorMessage = "First Name can only have 50 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [StringLength(maximumLength: 50, ErrorMessage = "Last Name can only have 50 characters")]
        public string LastName { get; set; }

        public string UserRights { get; set; } = "READER";

        [Required(ErrorMessage = "Password is required")]
        public string Password { get; set; }
    }
}