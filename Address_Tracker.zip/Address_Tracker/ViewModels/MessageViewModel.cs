﻿using System;
using System.ComponentModel.DataAnnotations;
using Address_Tracker.Models;

namespace Address_Tracker.ViewModels
{
    public class MessageViewModel
    {
        [Required, MaxLength(125, ErrorMessage = "Subject is to long, please shorten it.")]
        public string Subject { get; set; }

        [Required, MaxLength(5000)]
        public string NotificationMessage { get; set; }

        [Required, MaxLength(100, ErrorMessage = "Name has to many characters.")]
        public string Name { get; set; }

        [Required, MaxLength(25, ErrorMessage = "Phone has to many characters.")]
        public string Phone { get; set; }

        [Required, MaxLength(150, ErrorMessage = "Email has to many characters."), EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string EmailAddress { get; set; }

        public DateTime? DateSent { get; set; }

        public PhoneNumber PhoneNumber => new PhoneNumber(Phone);

        public bool ShowSubmitButtons { get; set; } = true;
    }
}