﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class DirectionController:_SimpleController<Direction>
    {
        public DirectionController(IRepository<Direction> repository) : base(repository)
        {
        }
    }
}