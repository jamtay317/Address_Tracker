﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class PointTypeController:_SimpleController<PointType>
    {
        public PointTypeController(IRepository<PointType> repository) : base(repository)
        {
        }
    }
}