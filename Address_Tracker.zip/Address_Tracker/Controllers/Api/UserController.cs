﻿using System.Linq;
using System.Web.Http;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Constants;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.PasswordService;

namespace Address_Tracker.Controllers.Api
{
    public class UserController:_SimpleController<User>
    {
        private readonly IRepository<User> _repository;

        public UserController(IRepository<User> repository) : base(repository)
        {
            _repository = repository;
        }

        public override IHttpActionResult Get()
        {
            var userDtos = _repository.Get()
                .Select(x => new UserDto() {Id = x.Id, FirstName = x.FirstName, LastName = x.LastName});

            return Ok(userDtos);
        }

        public override IHttpActionResult Get(int id)
        {
            var user =  _repository.Get(id);

            var privilege = UserRights.AllRights.First(x => x.saveName == user.UserRights).displayName;
            user.UserRights = privilege;
            return Ok(user);
        }

        [HttpPost]
        [Route("api/User/RegisterUser")]
        public IHttpActionResult RegisterUser([FromBody] User user)
        {
            user.UserRights = UserRights.Reader.saveName;
            user.Password = PasswordHelper.Hash(user.Password);
            _repository.Post(user);
            return Ok();
        }

        [HttpGet]
        [Route("api/User/GetPrivileges")]
        public IHttpActionResult GetPrivileges()
        {
            var privileges = new[]
            {
                UserRights.Reader.displayName,
                UserRights.Editor.displayName,
                UserRights.Admin.displayName
            };
            return Ok(privileges.Select(x=> new { Name = x }));
        }

        [HttpPost]
        [Route("api/User/UpdateUser")]
        public IHttpActionResult UpdateUser([FromBody] User user)
        {
            user.UserRights = UserRights.AllRights.First(x => x.displayName == user.UserRights).saveName;
            var savedUser = _repository.Patch(user);
            return Ok(savedUser);
        }
    }
}