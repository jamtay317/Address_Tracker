﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class ZoningController:_SimpleController<Zoning>
    {
        public ZoningController(IRepository<Zoning> repository) : base(repository)
        {
        }
    }
}