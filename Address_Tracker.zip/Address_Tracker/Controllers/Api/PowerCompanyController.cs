﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class PowerCompanyController:_SimpleController<PowerCompany>
    {
        public PowerCompanyController(IRepository<PowerCompany> repository) : base(repository)
        {
        }
    }
}