﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Address_Tracker.Data.Logger;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.AddressSearchService;
using Address_Tracker.Services.AddressService;
using Address_Tracker.Services.FileServices;

namespace Address_Tracker.Controllers.Api
{
    public class AddressSearchController:_SimpleController<Address>
    {
        private readonly IRepository<Address> _addressRepository;
        private readonly IAddressSearchService _addressSearchService;
        private readonly IAddressService _addressService;
        private readonly ICsvService _csvService;

        public AddressSearchController(IRepository<Address> addressRepository,
            IAddressSearchService addressSearchService,
            IAddressService addressService,
            ICsvService csvService) : base(addressRepository)
        {
            _addressRepository = addressRepository;
            _addressSearchService = addressSearchService;
            _addressService = addressService;
            _csvService = csvService;
        }

        [HttpPost]
        [Route("api/AddressSearch/Search")]
        public IHttpActionResult Search([FromBody]AddressSearchDto dto)
        {
            var results = _addressSearchService.Search(dto);

            return Ok(results);
        }

        [HttpPost]
        [Route("api/AddressSearch/Export")]
        public HttpResponseMessage Export([FromBody]AddressSearchDto dto)
        {
            var addressDtos = _addressSearchService.SearchAddressJoinedToAllTables(dto);

            var csv = _csvService.Serialize(addressDtos);
            var root = CreateRootIfDoesntExist();
            var path = Path.Combine(root, "Temp.csv");

            if (File.Exists(path))
            {
                File.Delete(path);
            }

            File.WriteAllText(path,csv);

            var memoryStream = new MemoryStream(File.ReadAllBytes(path));

            var result =new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(memoryStream.ToArray())
            };

            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = "results.csv"
            };
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            return result;
        }

        [HttpPost]
        [Route("api/AddressSearch/Upload")]
        public async Task<HttpResponseMessage> Upload()
        {
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            var root = CreateRootIfDoesntExist();

            var provider = new MultipartFormDataStreamProvider(root);

            try
            {
                // Read the form data.
                await Request.Content.ReadAsMultipartAsync(provider);

                foreach (MultipartFileData fileData in provider.FileData)
                {
                    var bytes = File.ReadAllBytes(fileData.LocalFileName);

                    var directory = Path.GetDirectoryName(fileData.LocalFileName);
                    var csvPath = Path.Combine(directory, "temp.csv");

                    File.WriteAllBytes(csvPath, bytes);

                    var csv = File.ReadAllText(csvPath);
                    _addressService.DeleteAllAddresses();
                    _addressService.ImportCsv(csv);
                    _addressService.CleanUpFiles(directory);

                }

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception e)
            {
                AddressLogger.LogError($"Error in Upload at {DateTime.Now}: ", e);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, e);
            }
        }

        private static string CreateRootIfDoesntExist()
        {
            var root = HttpContext.Current.Server.MapPath("~/App_Data");
            if (!Directory.Exists(root))
            {
                Directory.CreateDirectory(root);
            }

            return root;
        }

        public override IHttpActionResult Get(int id)
        {
            var address = _addressRepository.Get(id);
            return Ok(address);
        }
    }
}