﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class CommunityController:_SimpleController<Community>
    {
        public CommunityController(IRepository<Community> repository) : base(repository)
        {
        }
    }
}