﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class DistrictController:_SimpleController<District>
    {
        public DistrictController(IRepository<District> repository) : base(repository)
        {
        }
    }
}