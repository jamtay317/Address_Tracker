﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class ZipCodeController:_SimpleController<ZipCode>
    {
        public ZipCodeController(IRepository<ZipCode> repository) : base(repository)
        {
        }
    }
}