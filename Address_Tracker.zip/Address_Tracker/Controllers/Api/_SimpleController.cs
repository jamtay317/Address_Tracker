﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models.Interfaces;

namespace Address_Tracker.Controllers.Api
{
    public abstract class _SimpleController<T>:ApiController where T:class, IEntity, new()
    {
        private readonly IRepository<T> _repository;

        protected _SimpleController(IRepository<T> repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public virtual IHttpActionResult Get()
        {
            return Ok(_repository.Get());
        }

        [HttpGet]
        public virtual IHttpActionResult Get([FromUri] int id)
        {
            return Ok(_repository.Get(id));
        }

        [HttpPost]
        public virtual IHttpActionResult Post([FromBody] T entity)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            return Ok(_repository.Post(entity));
        }

        [HttpPut]
        public virtual IHttpActionResult Put([FromBody] T entity)
        {
            var databaseEntity = _repository.Get(entity.Id);
            if (databaseEntity == null)
                return BadRequest();

            return Ok(_repository.Patch(entity));
        }

        [HttpPatch]
        public virtual IHttpActionResult Patch([FromBody] T entity)
        {
            return Put(entity);
        }
    }

    
}