﻿using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;

namespace Address_Tracker.Controllers.Api
{
    public class MunicpalityController:_SimpleController<Municipality>
    {
        public MunicpalityController(IRepository<Municipality> repository) : base(repository)
        {
        }
    }
}