﻿using System.Web.Mvc;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;

namespace Address_Tracker.Controllers
{
    public class AddressController:Controller
    {
        public AddressController(IRepository<Address> addRepository)
        {
            
        }
        public ActionResult Index(LogedInUser user)
        {
            return View(user);
        }
    }
}