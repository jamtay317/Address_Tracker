﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Dtos;
using Address_Tracker.ViewModels;
using ASP.MessagingService;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Address_Tracker.Controllers
{
    public class MessageController : Controller
    {
        private readonly IRepository<Message> _messageRepository;
        private readonly IMessagingService _messagingService;

        public MessageController(IRepository<Message> messageRepository, IMessagingService messagingService)
        {
            _messageRepository = messageRepository;
            _messagingService = messagingService;
        }

        public ActionResult ContactUs()
        {
            var viewModel = new MessageViewModel();
            return View(viewModel);
        }

        [HttpPost]
        public JsonResult ContactUs(MessageViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                throw new InvalidOperationException();
            }

            var message = new Message()
            {
                EmailAddress = viewModel.EmailAddress,
                NotificationMessage = viewModel.NotificationMessage,
                PhoneNumber = viewModel.PhoneNumber.Value,
                SenderName = viewModel.Name,
                Subject = viewModel.Subject,
                DateSent = DateTime.Now
            };

            _messageRepository.Post(message);
           // _messagingService.Send(message.Subject, message.NotificationMessage);
            return Json(new {});
        }

        [HttpGet]
        public string CheckMessages()
        {
            var viewModel = GetCurrentMessages();

            return JsonConvert.SerializeObject(viewModel, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() });
        }

        private CheckMessagesViewModel GetCurrentMessages()
        {
            var lastMessageDate = DateTime.Today.AddDays(-7);
            var notReadMessages = _messageRepository
                .Get()
                .Where(message => !message.IsRead);

            var sevenDaysAgoDate = DateTime.Today.AddDays(-7);

            var readMessageForPast7Days = _messageRepository
                    .Get()
                    .Where(message => message.DateRead > sevenDaysAgoDate);

            var messages = readMessageForPast7Days
                .Union(notReadMessages)
                .Select(message => new MessageDto()
                {
                    Id = message.Id,
                    DateSent = message.DateSent,
                    IsRead = message.IsRead,
                    SenderName = message.SenderName,
                    Subject = message.Subject
                })
                .OrderByDescending(message => message.DateSent)
                .ThenBy(message => message.SenderName)
                .ToList();

            var viewModel = new CheckMessagesViewModel() { Messages = messages };
            return viewModel;
        }

        [HttpGet]
        public string SelectMessage(int id)
        {
            var model = _messageRepository.Get(id);
            model.IsRead = true;
            model.DateRead = DateTime.Now;
            _messageRepository.Patch(model);
            var message = new MessageViewModel()
            {
                DateSent = model.DateSent,
                EmailAddress = model.EmailAddress,
                Name = model.SenderName,
                NotificationMessage = model.NotificationMessage,
                Phone = model.PhoneNumber,
                Subject = model.Subject,
                ShowSubmitButtons = false
            };

            var viewModel = GetCurrentMessages();
            viewModel.SelectedMessage = message;
            
            return JsonConvert.SerializeObject(viewModel, new JsonSerializerSettings() { ContractResolver = new CamelCasePropertyNamesContractResolver() });
        } 
    }
}