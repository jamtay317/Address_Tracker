﻿using System.Linq;
using System.Web.Mvc;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Models.Constants;
using Address_Tracker.Models.Dtos;
using Address_Tracker.Services.PasswordService;
using Address_Tracker.ViewModels;
using ASP.Session;
using ASP.SystemSettingsService;

namespace Address_Tracker.Controllers
{
    public class LoginController : Controller
    {
        private readonly IRepository<User> _userRepository;
        private readonly ISessionService _sessionService;
        private readonly ISystemSettingsService _systemSettingsService;

        public LoginController(IRepository<User> userRepository, ISessionService sessionService, ISystemSettingsService systemSettingsService)
        {
            @ViewBag.InvalidLogin = false;
            @ViewBag.UndefindUser = false;
            _userRepository = userRepository;
            _sessionService = sessionService;
            _systemSettingsService = systemSettingsService;
        }

        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(UserViewModel user)
        {
            if(!ModelState.IsValid)
            {
                return View(user);
            }

            var hashedPassword = PasswordHelper.Hash(user.Password);
            var databaseUser = _userRepository.Get().FirstOrDefault(x => x.Username.ToLower() == user.Username.ToLower() && x.HasAccess);

            if (databaseUser == null)
            {
                @ViewBag.UndefindUser = true;
                user.Password = null;

                return View(user);
            }
            if (hashedPassword != databaseUser.Password)
            {
                @ViewBag.InvalidLogin = true;
                user.Password = null;
                return View(user);
            }

            var session = _sessionService.UpdateOrStartActiveSession(databaseUser.Username);
            
            var logedInUser = new LogedInUser()
            {
                Role = databaseUser.UserRights,
                Username = databaseUser.Username,
                DaysUntillTimeout = _systemSettingsService.SystemSettings.SessionTimeOutInDays,
                LastLogin = session.LastLogin,
                SessionExpires = session.Expires
            };

            return RedirectToAction("Index", "Address", logedInUser);
        }

        [HttpGet]
        public void Logout(string username)
        {
            _sessionService.Logout(username);
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(RegisterViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(viewModel);
            }

            var user = new User()
            {
                EmailAddress =  viewModel.Email,
                FirstName = viewModel.FirstName,
                LastName = viewModel.LastName,
                HasAccess = false,
                Password = PasswordHelper.Hash(viewModel.Password),
                Username = viewModel.Username,
                UserRights = UserRights.Reader.saveName
            };

            var databaseUser = _userRepository.Get().FirstOrDefault(x => x.Username == viewModel.Username);
            if (databaseUser != null)
            {
                viewModel.AlreadyRegisterd = true;
                return View(viewModel);
            }

            _userRepository.Post(user);
            return RedirectToAction("Index");
        }
    }
}