﻿using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using System.Web.UI.WebControls;
using Address_Tracker.Data.ConfigurationServices;
using Address_Tracker.Services.Reports.Service;
using Address_Tracker.ViewModels;
using Microsoft.Reporting.WebForms;

namespace Address_Tracker.Controllers
{
    public class ReportController : Controller
    {
        private readonly IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService;
        }
        public ActionResult ReportChooser(int? id)
        {
            var reportViewModel = new ReportChooserViewModel();
            var dtos = _reportService.GetReportDtos().OrderBy(x => x.DisplayName).ToList();

            reportViewModel.ReportDtos = dtos;

            if (id.HasValue)
            {
                ViewBag.ReportViewer = _reportService.GetReport(id.Value, Request.MapPath(Request.ApplicationPath));
                ViewBag.ReportName = dtos.FirstOrDefault(x => x.Id == id.Value)?.DisplayName;
            }
            return View(reportViewModel);
        }
    }
}