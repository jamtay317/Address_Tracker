using System;
using Address_Tracker.App_Start;
using Address_Tracker.Data.ConfigurationServices;
using Address_Tracker.Data.Context;
using Address_Tracker.Data.Context.Interfaces;
using Address_Tracker.Data.Repositories;
using Address_Tracker.Models;
using Address_Tracker.Services.AddressSearchService;
using Address_Tracker.Services.AddressService;
using Address_Tracker.Services.AdoSqlService;
using Address_Tracker.Services.DatabaseColumnsService;
using Address_Tracker.Services.FileServices;
using Address_Tracker.Services.FileServices.FileHeaders;
using Address_Tracker.Services.Reports.Service;
using ASP.MessagingService;
using ASP.Session;
using ASP.SystemSettingsService;
using AutoMapper;
using Unity;
using Unity.AspNet.Mvc;
using Unity.Injection;
using Unity.Lifetime;

namespace Address_Tracker
{
    /// <summary>
    /// Specifies the Unity configuration for the main container.
    /// </summary>
    public static class UnityConfig
    {
        #region Unity Container
        private static Lazy<IUnityContainer> container =
          new Lazy<IUnityContainer>(() =>
          {
              var container = new UnityContainer();
              RegisterTypes(container);
              return container;
          });

        /// <summary>
        /// Configured Unity Container.
        /// </summary>
        public static IUnityContainer Container => container.Value;
        #endregion

        /// <summary>
        /// Registers the type mappings with the Unity container.
        /// </summary>
        /// <param name="container">The unity container to configure.</param>
        /// <remarks>
        /// There is no need to register concrete types such as controllers or
        /// API controllers (unless you want to change the defaults), as Unity
        /// allows resolving a concrete type even if it was not previously
        /// registered.
        /// </remarks>
        public static void RegisterTypes(IUnityContainer container)
        {
            RegisterInstances(container);
            RegisterSingletons(container);
        }

        private static void RegisterInstances(IUnityContainer container)
        {
            
            container.RegisterType(typeof(IRepository<>), typeof(Repository<>));
            container.RegisterType<IAddressSearchService, AddressSearchService>();
            container.RegisterType<ICsvService, CsvService>();
            container.RegisterType<IAddressService, AddressService>();
            container.RegisterType<IAdoSqlService, AdoSqlService>();
            container.RegisterType<ICsvFileHeaderFactory, CsvFileHeaderFactory>();
            container.RegisterType<IDatabaseColumnDefinition, DatabaseColumnDefinition>();
            container.RegisterType<IReportService, ReportService>();
            container.RegisterType<IMessagingService, MessagingService>();
            container.RegisterType<ISessionService, SessionService>();

        }

        private static void RegisterSingletons(IUnityContainer container)
        {
            container.RegisterType<IAddressContext, AddressContext>(new PerRequestLifetimeManager());
            container.RegisterType<IConfigurationService, ConfigurationService>();
            container.RegisterType<ISystemSettingsService, SystemSettingsService>(new ContainerControlledLifetimeManager());
        }
    }
}